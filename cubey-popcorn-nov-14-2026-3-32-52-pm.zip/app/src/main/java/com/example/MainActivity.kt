package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppScreen
import com.example.ui.GameScreen
import com.example.ui.GameViewModel
import com.example.ui.PowerUpShopScreen
import com.example.ui.SettingsScreen
import com.example.ui.StageSelectScreen
import com.example.ui.TitleScreen
import com.example.ui.VictoryScreen
import com.example.ui.theme.CubeyPopcornTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CubeyPopcornTheme {
                val vm: GameViewModel = viewModel()
                val progress by vm.progress.collectAsStateWithLifecycle()
                val screen by vm.currentScreen.collectAsStateWithLifecycle()
                val overlay by vm.overlayState.collectAsStateWithLifecycle()
                val hud by vm.hudState.collectAsStateWithLifecycle()

                val lifecycleOwner = LocalLifecycleOwner.current
                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        when (event) {
                            Lifecycle.Event.ON_PAUSE -> vm.onAppBackgrounded()
                            Lifecycle.Event.ON_RESUME -> vm.onAppForegrounded()
                            else -> Unit
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose {
                        lifecycleOwner.lifecycle.removeObserver(observer)
                    }
                }

                when (screen) {
                    AppScreen.TITLE -> {
                        TitleScreen(
                            progress = progress,
                            onPlayClick = { vm.startOrResumeAdventure() },
                            onStageSelectClick = { vm.navigateTo(AppScreen.STAGE_SELECT) },
                            onShopClick = { vm.navigateTo(AppScreen.SHOP) },
                            onSettingsClick = { vm.navigateTo(AppScreen.SETTINGS) }
                        )
                    }

                    AppScreen.STAGE_SELECT -> {
                        StageSelectScreen(
                            progress = progress,
                            onStageSelected = { stageNum ->
                                vm.startStage(stageNum, resetRunScore = true)
                            },
                            onTogglePracticeMode = { enabled ->
                                vm.setPracticeMode(enabled)
                            },
                            onBack = { vm.navigateTo(AppScreen.TITLE) }
                        )
                    }

                    AppScreen.PLAYING -> {
                        GameScreen(
                            engine = vm.engine,
                            hud = hud,
                            overlayState = overlay,
                            onPauseClick = { vm.pauseGame() },
                            onResumeClick = { vm.resumeGame() },
                            onRestartStageClick = { vm.restartCurrentStageFromPause() },
                            onRetryAfterGameOver = { vm.retryCurrentStageAfterGameOver() },
                            onNextStageClick = { vm.proceedToNextStage() },
                            onOpenShopClick = { vm.navigateTo(AppScreen.SHOP) },
                            onOpenSettingsClick = { vm.navigateTo(AppScreen.SETTINGS) },
                            onExitToStages = { vm.navigateTo(AppScreen.STAGE_SELECT) }
                        )
                    }

                    AppScreen.SHOP -> {
                        PowerUpShopScreen(
                            progress = progress,
                            onUnlockPowerUp = { vm.unlockPowerUp(it) },
                            onToggleEquipped = { vm.togglePowerUpEquipped(it) },
                            onBack = { vm.navigateTo(AppScreen.TITLE) }
                        )
                    }

                    AppScreen.SETTINGS -> {
                        SettingsScreen(
                            progress = progress,
                            onAudioChanged = { music, sfx, preview ->
                                vm.updateAudioSettings(music, sfx, preview)
                            },
                            onGraphicsQualityChanged = { vm.updateGraphicsQuality(it) },
                            onPracticeModeChanged = { vm.setPracticeMode(it) },
                            onResetProgress = { vm.resetAllProgress() },
                            onBack = { vm.navigateTo(AppScreen.TITLE) }
                        )
                    }

                    AppScreen.VICTORY -> {
                        VictoryScreen(
                            hud = hud,
                            progress = progress,
                            onPlayAgainBoss = { vm.startStage(90, resetRunScore = true) },
                            onStageSelect = { vm.navigateTo(AppScreen.STAGE_SELECT) },
                            onHome = { vm.navigateTo(AppScreen.TITLE) }
                        )
                    }
                }
            }
        }
    }
}
