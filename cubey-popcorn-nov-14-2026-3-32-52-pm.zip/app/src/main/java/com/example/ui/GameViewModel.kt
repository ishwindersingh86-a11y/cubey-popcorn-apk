package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.ArcadeSoundEngine
import com.example.audio.SoundEffect
import com.example.data.GameProgress
import com.example.data.GameProgressRepository
import com.example.data.GraphicsQuality
import com.example.data.PowerUpType
import com.example.game.GameEngine
import com.example.game.HudSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    TITLE,
    STAGE_SELECT,
    PLAYING,
    SHOP,
    SETTINGS,
    VICTORY
}

sealed interface PlayOverlayState {
    data object None : PlayOverlayState
    data object Paused : PlayOverlayState
    data class StageCleared(
        val stageNumber: Int,
        val stageTitle: String,
        val score: Int,
        val highScore: Int,
        val stagePopcorn: Int
    ) : PlayOverlayState
    data class GameOver(
        val stageNumber: Int,
        val score: Int,
        val highScore: Int,
        val isNewHighScore: Boolean,
        val popcornEarned: Int
    ) : PlayOverlayState
}

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GameProgressRepository(application.applicationContext)
    val soundEngine = ArcadeSoundEngine()

    val progress: StateFlow<GameProgress> = repository.progressFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = GameProgress()
    )

    private val _currentScreen = MutableStateFlow(AppScreen.TITLE)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _overlayState = MutableStateFlow<PlayOverlayState>(PlayOverlayState.None)
    val overlayState: StateFlow<PlayOverlayState> = _overlayState.asStateFlow()

    private val _hudState = MutableStateFlow(HudSnapshot())
    val hudState: StateFlow<HudSnapshot> = _hudState.asStateFlow()

    private var currentRunScore = 0
    private var currentStageNumber = 1

    val engine: GameEngine = GameEngine(
        soundEngine = soundEngine,
        onStageCleared = { stageNum, finalRunScore, popcornEarned ->
            currentRunScore = finalRunScore
            viewModelScope.launch {
                repository.saveStageClear(stageNum, finalRunScore, popcornEarned)
            }
            if (stageNum == 90) {
                _overlayState.value = PlayOverlayState.None
                _currentScreen.value = AppScreen.VICTORY
            } else {
                _overlayState.value = PlayOverlayState.StageCleared(
                    stageNumber = stageNum,
                    stageTitle = _hudState.value.stageTitle,
                    score = finalRunScore,
                    highScore = maxOf(progress.value.highScore, finalRunScore),
                    stagePopcorn = _hudState.value.stagePopcorn
                )
            }
        },
        onGameOver = { finalRunScore, popcornEarned ->
            val previousHigh = progress.value.highScore
            val isNewHigh = finalRunScore > previousHigh
            viewModelScope.launch {
                repository.saveAfterGameOver(finalRunScore, popcornEarned)
            }
            _overlayState.value = PlayOverlayState.GameOver(
                stageNumber = currentStageNumber,
                score = finalRunScore,
                highScore = maxOf(previousHigh, finalRunScore),
                isNewHighScore = isNewHigh,
                popcornEarned = popcornEarned
            )
            currentRunScore = 0
        },
        onHudUpdated = { snapshot ->
            _hudState.value = snapshot
        }
    )

    init {
        soundEngine.start()
        viewModelScope.launch {
            progress.collect { p ->
                soundEngine.musicVolume = p.musicVolume
                soundEngine.sfxVolume = p.sfxVolume
                engine.graphicsQuality = p.graphicsQuality
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        if (screen != AppScreen.PLAYING) {
            soundEngine.isBossMusic = false
        }
        _overlayState.value = PlayOverlayState.None
        _currentScreen.value = screen
    }

    fun startOrResumeAdventure() {
        val targetStage = progress.value.maxUnlockedStage.coerceIn(1, 90)
        startStage(targetStage, resetRunScore = true)
    }

    fun startStage(stageNumber: Int, resetRunScore: Boolean = true, preserveHearts: Boolean = false) {
        val clamped = stageNumber.coerceIn(1, 90)
        currentStageNumber = clamped
        if (resetRunScore) {
            currentRunScore = 0
        }
        val p = progress.value
        engine.loadStage(
            stageNumber = clamped,
            currentScore = currentRunScore,
            savedHighScore = p.highScore,
            savedPopcorn = p.totalPopcorn,
            equippedPowerUps = p.equippedPowerUps,
            quality = p.graphicsQuality,
            preserveHearts = preserveHearts
        )
        _overlayState.value = PlayOverlayState.None
        _currentScreen.value = AppScreen.PLAYING
    }

    fun proceedToNextStage() {
        val next = (currentStageNumber + 1).coerceAtMost(90)
        startStage(next, resetRunScore = false, preserveHearts = true)
    }

    fun retryCurrentStageAfterGameOver() {
        startStage(currentStageNumber, resetRunScore = true, preserveHearts = false)
    }

    fun pauseGame() {
        if (_currentScreen.value == AppScreen.PLAYING && _overlayState.value == PlayOverlayState.None) {
            engine.leftPressed = false
            engine.rightPressed = false
            _overlayState.value = PlayOverlayState.Paused
        }
    }

    fun resumeGame() {
        if (_overlayState.value == PlayOverlayState.Paused) {
            _overlayState.value = PlayOverlayState.None
        }
    }

    fun restartCurrentStageFromPause() {
        startStage(currentStageNumber, resetRunScore = true, preserveHearts = false)
    }

    fun unlockPowerUp(type: PowerUpType) {
        viewModelScope.launch {
            val bought = repository.unlockPowerUp(type)
            if (bought) {
                soundEngine.playSfx(SoundEffect.POWERUP)
            }
        }
    }

    fun togglePowerUpEquipped(type: PowerUpType) {
        viewModelScope.launch {
            repository.togglePowerUpEquipped(type)
            soundEngine.playSfx(SoundEffect.POPCORN)
        }
    }

    fun updateAudioSettings(musicVolume: Float, sfxVolume: Float, playPreviewSfx: Boolean = false) {
        soundEngine.musicVolume = musicVolume
        soundEngine.sfxVolume = sfxVolume
        if (playPreviewSfx) {
            soundEngine.playSfx(SoundEffect.POPCORN)
        }
        viewModelScope.launch {
            repository.updateAudioSettings(musicVolume, sfxVolume)
        }
    }

    fun updateGraphicsQuality(quality: GraphicsQuality) {
        engine.graphicsQuality = quality
        viewModelScope.launch {
            repository.updateGraphicsQuality(quality)
        }
    }

    fun setPracticeMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.setPracticeMode(enabled)
        }
    }

    fun resetAllProgress() {
        currentRunScore = 0
        viewModelScope.launch {
            repository.resetProgress()
        }
    }

    fun onAppBackgrounded() {
        soundEngine.setPaused(true)
        pauseGame()
    }

    fun onAppForegrounded() {
        soundEngine.setPaused(false)
    }

    override fun onCleared() {
        super.onCleared()
        soundEngine.stop()
    }
}
