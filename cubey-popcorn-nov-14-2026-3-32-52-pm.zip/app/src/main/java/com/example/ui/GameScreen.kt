package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameEngine
import com.example.game.HudSnapshot
import com.example.ui.theme.ButterGold
import com.example.ui.theme.CinemaCrimson
import com.example.ui.theme.CubeyCyan
import com.example.ui.theme.DeepIndigoSurface
import com.example.ui.theme.ElevatedCardIndigo
import com.example.ui.theme.EmeraldPop
import com.example.ui.theme.KernelCream
import com.example.ui.theme.MidnightTheater
import com.example.ui.theme.MutedLavender
import com.example.ui.theme.OutlineIndigo

@Composable
fun GameScreen(
    engine: GameEngine,
    hud: HudSnapshot,
    overlayState: PlayOverlayState,
    onPauseClick: () -> Unit,
    onResumeClick: () -> Unit,
    onRestartStageClick: () -> Unit,
    onRetryAfterGameOver: () -> Unit,
    onNextStageClick: () -> Unit,
    onOpenShopClick: () -> Unit,
    onOpenSettingsClick: () -> Unit,
    onExitToStages: () -> Unit
) {
    BackHandler {
        if (overlayState == PlayOverlayState.None) {
            onPauseClick()
        } else if (overlayState == PlayOverlayState.Paused) {
            onResumeClick()
        } else {
            onExitToStages()
        }
    }

    var frameTick by remember { mutableLongStateOf(0L) }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightTheater)
            .onPreviewKeyEvent { keyEvent ->
                val isDown = keyEvent.type == KeyEventType.KeyDown
                val isUp = keyEvent.type == KeyEventType.KeyUp
                if (!isDown && !isUp) return@onPreviewKeyEvent false
                when (keyEvent.key) {
                    Key.DirectionLeft, Key.A -> {
                        engine.leftPressed = isDown
                        true
                    }
                    Key.DirectionRight, Key.D -> {
                        engine.rightPressed = isDown
                        true
                    }
                    Key.Spacebar, Key.W, Key.DirectionUp -> {
                        if (isDown) engine.onJumpPressed() else engine.onJumpReleased()
                        true
                    }
                    else -> false
                }
            }
    ) {
        val aspect = if (maxHeight.value > 0f) maxWidth.value / maxHeight.value else 16f / 9f
        val viewportWorldHeight = 640f
        val viewportWorldWidth = (viewportWorldHeight * aspect).coerceIn(460f, 1180f)

        // 60Hz+ Frame-Driven Physics Loop
        LaunchedEffect(overlayState, viewportWorldWidth) {
            if (overlayState != PlayOverlayState.None) return@LaunchedEffect
            var lastNanos = 0L
            while (true) {
                withFrameNanos { now ->
                    if (lastNanos != 0L) {
                        val dt = (now - lastNanos) / 1_000_000_000f
                        engine.step(dt, viewportWorldWidth, viewportWorldHeight)
                    }
                    lastNanos = now
                    frameTick++
                }
            }
        }

        // 1. Game Canvas
        GameCanvas(
            engine = engine,
            frameTick = frameTick,
            viewportWorldWidth = viewportWorldWidth,
            viewportWorldHeight = viewportWorldHeight,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Top Arcade HUD
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left HUD Pill: Hearts + Stage
                Surface(
                    color = DeepIndigoSurface.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.border(1.dp, OutlineIndigo, RoundedCornerShape(14.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (i in 0 until hud.maxHearts) {
                            Icon(
                                imageVector = if (i < hud.hearts) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = "Heart",
                                tint = if (i < hud.hearts) CinemaCrimson else MutedLavender.copy(alpha = 0.4f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        if (hud.hasShield) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = "Butter Shield Active",
                                tint = ButterGold,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "STG ${hud.stageNumber}/90",
                            style = MaterialTheme.typography.labelMedium,
                            color = CubeyCyan
                        )
                    }
                }

                // Center/Right HUD Pill: Score Meter (+1 per enemy stomp), High Score & Popcorn
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = DeepIndigoSurface.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.border(1.dp, OutlineIndigo, RoundedCornerShape(14.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "SCORE ${hud.score}",
                                style = MaterialTheme.typography.labelMedium.copy(fontSize = 13.sp),
                                color = EmeraldPop,
                                modifier = Modifier.testTag("hud_score")
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.EmojiEvents,
                                    contentDescription = "High Score",
                                    tint = ButterGold,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "${hud.highScore}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ButterGold,
                                    modifier = Modifier.testTag("hud_high_score")
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Star,
                                    contentDescription = "Popcorn",
                                    tint = ButterGold,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "${hud.totalPopcorn}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = KernelCream,
                                    modifier = Modifier.testTag("hud_popcorn")
                                )
                            }
                        }
                    }

                    // Pause button (48dp touch target)
                    Surface(
                        color = DeepIndigoSurface.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.border(1.dp, OutlineIndigo, RoundedCornerShape(14.dp))
                    ) {
                        IconButton(
                            onClick = onPauseClick,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("pause_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Pause,
                                contentDescription = "Pause Game",
                                tint = KernelCream
                            )
                        }
                    }
                }
            }

            // Stage 90 Boss Health Bar
            if (hud.isBossStage) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = DeepIndigoSurface.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .widthIn(max = 480.dp)
                        .fillMaxWidth()
                        .border(1.5.dp, CinemaCrimson, RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "BURNT KERNEL EMPEROR • PHASE ${hud.bossPhase}/4",
                                style = MaterialTheme.typography.labelMedium,
                                color = ButterGold
                            )
                            Text(
                                text = "${hud.bossHp}/${hud.bossMaxHp} HP",
                                style = MaterialTheme.typography.labelMedium,
                                color = CinemaCrimson
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { (hud.bossHp.toFloat() / hud.bossMaxHp.toFloat()).coerceIn(0f, 1f) },
                            color = CinemaCrimson,
                            trackColor = MidnightTheater,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )
                    }
                }
            }

            // Transient Status Banner (e.g. Spike reset / Boss Phase)
            hud.statusBanner?.let { msg ->
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = CinemaCrimson.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.labelLarge,
                        color = KernelCream,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // 3. Multi-touch On-Screen Controls (Jump on Left, Left/Right on Right)
        if (overlayState == PlayOverlayState.None) {
            TouchControlsOverlay(
                onJumpPressed = { engine.onJumpPressed() },
                onJumpReleased = { engine.onJumpReleased() },
                onLeftChanged = { engine.leftPressed = it },
                onRightChanged = { engine.rightPressed = it }
            )
        }

        // 4. Overlay Dialogs (Paused / Stage Cleared / Game Over)
        when (overlayState) {
            PlayOverlayState.None -> Unit

            PlayOverlayState.Paused -> {
                ArcadeModalOverlay(
                    title = "PAUSED",
                    subtitle = "Stage ${hud.stageNumber}: ${hud.stageTitle}",
                    accent = CubeyCyan
                ) {
                    Button(
                        onClick = onResumeClick,
                        colors = ButtonDefaults.buttonColors(containerColor = ButterGold, contentColor = MidnightTheater),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("resume_button")
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Resume", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onRestartStageClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("pause_restart_button")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, tint = KernelCream)
                        Spacer(Modifier.width(6.dp))
                        Text("Restart Stage", color = KernelCream)
                    }
                    OutlinedButton(
                        onClick = onOpenSettingsClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text("Audio & Graphics Settings", color = KernelCream)
                    }
                    OutlinedButton(
                        onClick = onExitToStages,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text("Stage Select", color = MutedLavender)
                    }
                }
            }

            is PlayOverlayState.StageCleared -> {
                ArcadeModalOverlay(
                    title = "STAGE ${overlayState.stageNumber} CLEARED!",
                    subtitle = overlayState.stageTitle,
                    accent = EmeraldPop
                ) {
                    OverlayStatRow("Score", "${overlayState.score}", EmeraldPop)
                    OverlayStatRow("High Score", "${overlayState.highScore}", ButterGold)
                    OverlayStatRow("Stage Popcorn", "+${overlayState.stagePopcorn} 🍿", ButterGold)
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = onNextStageClick,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPop, contentColor = MidnightTheater),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("next_stage_button")
                    ) {
                        Text("Next: Stage ${overlayState.stageNumber + 1}", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onOpenShopClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text("Popcorn Power-Ups", color = ButterGold)
                    }
                    OutlinedButton(
                        onClick = onExitToStages,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text("Stage Select", color = MutedLavender)
                    }
                }
            }

            is PlayOverlayState.GameOver -> {
                ArcadeModalOverlay(
                    title = "GAME OVER",
                    subtitle = if (overlayState.isNewHighScore) "NEW HIGH SCORE SAVED!" else "Progress Saved",
                    accent = CinemaCrimson
                ) {
                    OverlayStatRow("Run Score", "${overlayState.score}", KernelCream)
                    OverlayStatRow("High Score", "${overlayState.highScore}", ButterGold)
                    OverlayStatRow("Popcorn Saved", "+${overlayState.popcornEarned} 🍿", CubeyCyan)
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = onRetryAfterGameOver,
                        colors = ButtonDefaults.buttonColors(containerColor = ButterGold, contentColor = MidnightTheater),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("retry_stage_button")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Retry Stage ${overlayState.stageNumber}", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onOpenShopClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text("Unlock Power-Ups", color = ButterGold)
                    }
                    OutlinedButton(
                        onClick = onExitToStages,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text("Stage Select", color = MutedLavender)
                    }
                }
            }
        }
    }
}

@Composable
private fun ArcadeModalOverlay(
    title: String,
    subtitle: String,
    accent: Color,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightTheater.copy(alpha = 0.72f))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = ElevatedCardIndigo),
            shape = MaterialTheme.shapes.large,
            modifier = Modifier
                .widthIn(max = 380.dp)
                .fillMaxWidth()
                .border(2.dp, accent, MaterialTheme.shapes.large)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = accent,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedLavender,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                content()
            }
        }
    }
}

@Composable
private fun OverlayStatRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(DeepIndigoSurface)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MutedLavender)
        Text(text = value, style = MaterialTheme.typography.titleMedium, color = valueColor)
    }
}
