package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ArcadeDarkColorScheme = darkColorScheme(
    primary = ButterGold,
    onPrimary = MidnightTheater,
    primaryContainer = CaramelOrange,
    onPrimaryContainer = KernelCream,
    secondary = CubeyCyan,
    onSecondary = MidnightTheater,
    secondaryContainer = CubeyCyanDark,
    onSecondaryContainer = KernelCream,
    tertiary = CinemaCrimson,
    onTertiary = KernelCream,
    background = MidnightTheater,
    onBackground = KernelCream,
    surface = DeepIndigoSurface,
    onSurface = KernelCream,
    surfaceVariant = ElevatedCardIndigo,
    onSurfaceVariant = MutedLavender,
    outline = OutlineIndigo,
    error = CinemaCrimson,
    onError = KernelCream
)

private val ArcadeShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun CubeyPopcornTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ArcadeDarkColorScheme,
        typography = AppTypography,
        shapes = ArcadeShapes,
        content = content
    )
}
