package com.example.game

import kotlin.math.min
import kotlin.random.Random

/**
 * Generates all 90 playable stages deterministically.
 * Reachability invariants (guaranteed across Stages 1..89):
 * - Max jump height with base physics is ~130 units -> vertical steps capped at <= 88 units.
 * - Max horizontal jump span is ~235 units -> pit/platform gaps capped at <= 150 units.
 * - Stage 90 is the dedicated multi-phase Burnt Kernel Emperor Boss Arena.
 */
object LevelGenerator {

    private const val GROUND_Y = 520f
    private const val FLOOR_HEIGHT = 120f
    private const val STAGE_HEIGHT = 720f

    fun getLevel(stageNumber: Int): LevelData {
        val clamped = stageNumber.coerceIn(1, 90)
        if (clamped == 90) {
            return buildBossStage90()
        }
        return buildStandardStage(clamped)
    }

    private fun buildStandardStage(stage: Int): LevelData {
        val rng = Random(stage * 7919 + 104729)
        val worldIndex = ((stage - 1) / 15).coerceIn(0, 5)
        val worldStage = ((stage - 1) % 15) + 1
        val difficulty = (stage - 1) / 89f // 0.0f -> 1.0f

        val platforms = mutableListOf<PlatformDef>()
        val spikes = mutableListOf<SpikeDef>()
        val enemies = mutableListOf<EnemySpawnDef>()
        val popcorn = mutableListOf<PopcornDef>()
        var nextPopcornId = 1

        // Safe starting platform
        var cursorX = 0f
        val startWidth = 340f
        platforms.add(PlatformDef(x = 0f, y = GROUND_Y, width = startWidth, height = FLOOR_HEIGHT))
        // Starter popcorn line
        popcorn.add(PopcornDef(nextPopcornId++, 170f, GROUND_Y - 56f))
        popcorn.add(PopcornDef(nextPopcornId++, 230f, GROUND_Y - 56f))
        cursorX = startWidth

        // Number of segments scales from 5 (Stage 1) to 13 (Stage 89)
        val segmentCount = 5 + (stage / 11).coerceAtMost(8)

        var currentFloorY = GROUND_Y

        for (seg in 0 until segmentCount) {
            val segType = when {
                stage == 1 && seg == 0 -> 0 // Friendly spike jump intro
                stage == 1 && seg == 1 -> 1 // Friendly enemy stomp intro
                stage <= 3 -> seg % 3
                else -> rng.nextInt(0, 6)
            }

            when (segType) {
                0 -> {
                    // Solid stretch with spike cluster(s) and overhead bonus platform
                    val stretchW = (280f + rng.nextFloat() * 140f)
                    platforms.add(PlatformDef(cursorX, currentFloorY, stretchW, FLOOR_HEIGHT))

                    val spikeWidth = if (stage <= 3) 44f else (52f + difficulty * 34f).coerceAtMost(88f)
                    val spikeX = cursorX + stretchW * 0.42f
                    spikes.add(SpikeDef(spikeX, currentFloorY - 26f, spikeWidth))

                    // Popcorn arc above spike
                    popcorn.add(PopcornDef(nextPopcornId++, spikeX + spikeWidth * 0.5f, currentFloorY - 98f))

                    // Optional upper ledge on later segments
                    if (stage >= 4 && rng.nextFloat() < 0.65f) {
                        val upperY = (currentFloorY - 84f).coerceAtLeast(240f)
                        val upperW = 130f
                        val upperX = cursorX + stretchW * 0.25f
                        platforms.add(PlatformDef(upperX, upperY, upperW, 24f))
                        popcorn.add(PopcornDef(nextPopcornId++, upperX + upperW * 0.5f, upperY - 40f))
                    }
                    cursorX += stretchW
                }

                1 -> {
                    // Enemy patrol arena platform
                    val platW = 280f + rng.nextFloat() * 120f
                    platforms.add(PlatformDef(cursorX, currentFloorY, platW, FLOOR_HEIGHT))

                    val enemyCount = if (stage >= 25 && rng.nextFloat() < 0.45f) 2 else 1
                    for (e in 0 until enemyCount) {
                        val eType = pickEnemyType(worldIndex, rng, stage)
                        val minX = cursorX + 24f + e * (platW * 0.45f)
                        val maxX = (minX + platW * 0.42f).coerceAtMost(cursorX + platW - 24f)
                        if (maxX - minX > 50f) {
                            val spawnY = if (eType == EnemyType.NEON_DRONE) currentFloorY - 90f else currentFloorY - 34f
                            enemies.add(
                                EnemySpawnDef(
                                    x = (minX + maxX) * 0.5f,
                                    y = spawnY,
                                    patrolMinX = minX,
                                    patrolMaxX = maxX,
                                    type = eType
                                )
                            )
                        }
                    }
                    popcorn.add(PopcornDef(nextPopcornId++, cursorX + platW * 0.5f, currentFloorY - 108f))
                    cursorX += platW
                }

                2 -> {
                    // Pit jump + elevated stepping stones
                    val gap1 = (88f + difficulty * 52f).coerceAtMost(142f)
                    cursorX += gap1
                    val stepDelta = if (rng.nextBoolean()) -64f else 48f
                    val nextY = (currentFloorY + stepDelta).coerceIn(270f, GROUND_Y)
                    val stepW = (145f - difficulty * 28f).coerceAtLeast(108f)
                    platforms.add(PlatformDef(cursorX, nextY, stepW, 26f))
                    popcorn.add(PopcornDef(nextPopcornId++, cursorX + stepW * 0.5f, nextY - 42f))
                    cursorX += stepW

                    val gap2 = (82f + difficulty * 50f).coerceAtMost(138f)
                    cursorX += gap2
                    currentFloorY = (nextY + 46f).coerceIn(300f, GROUND_Y)
                    val landW = 210f
                    platforms.add(PlatformDef(cursorX, currentFloorY, landW, FLOOR_HEIGHT))
                    if (stage >= 8 && rng.nextFloat() < 0.55f) {
                        val eType = pickEnemyType(worldIndex, rng, stage)
                        enemies.add(
                            EnemySpawnDef(
                                x = cursorX + landW * 0.55f,
                                y = currentFloorY - 34f,
                                patrolMinX = cursorX + 26f,
                                patrolMaxX = cursorX + landW - 26f,
                                type = eType
                            )
                        )
                    }
                    cursorX += landW
                }

                3 -> {
                    // Moving platform bridge over spike bed or pit
                    val useMoving = stage >= 6
                    if (useMoving) {
                        val leadW = 110f
                        platforms.add(PlatformDef(cursorX, currentFloorY, leadW, FLOOR_HEIGHT))
                        cursorX += leadW

                        val bridgeSpan = 260f + difficulty * 70f
                        val movW = 108f
                        val movRange = (bridgeSpan - movW - 40f).coerceAtLeast(60f)
                        platforms.add(
                            PlatformDef(
                                x = cursorX + 28f,
                                y = currentFloorY - 12f,
                                width = movW,
                                height = 24f,
                                type = PlatformType.MOVING_H,
                                moveRange = movRange,
                                moveSpeed = 1.15f + difficulty * 0.7f
                            )
                        )
                        // Spike pit floor below for safety visual
                        platforms.add(PlatformDef(cursorX, currentFloorY + 60f, bridgeSpan, 60f))
                        spikes.add(SpikeDef(cursorX + 16f, currentFloorY + 34f, bridgeSpan - 32f))
                        popcorn.add(PopcornDef(nextPopcornId++, cursorX + bridgeSpan * 0.35f, currentFloorY - 76f))
                        popcorn.add(PopcornDef(nextPopcornId++, cursorX + bridgeSpan * 0.65f, currentFloorY - 76f))
                        cursorX += bridgeSpan
                    } else {
                        val w = 220f
                        platforms.add(PlatformDef(cursorX, currentFloorY, w, FLOOR_HEIGHT))
                        popcorn.add(PopcornDef(nextPopcornId++, cursorX + w * 0.5f, currentFloorY - 48f))
                        cursorX += w
                    }
                }

                4 -> {
                    // Bouncy pad high-road + spike low-road
                    val baseW = 340f
                    platforms.add(PlatformDef(cursorX, currentFloorY, baseW, FLOOR_HEIGHT))
                    // Bouncy pad near start
                    platforms.add(
                        PlatformDef(
                            x = cursorX + 36f,
                            y = currentFloorY - 14f,
                            width = 74f,
                            height = 14f,
                            type = PlatformType.BOUNCY
                        )
                    )
                    // High bonus platform reachable via bounce
                    val highY = (currentFloorY - 170f).coerceAtLeast(180f)
                    platforms.add(PlatformDef(cursorX + 125f, highY, 175f, 24f))
                    popcorn.add(PopcornDef(nextPopcornId++, cursorX + 165f, highY - 42f))
                    popcorn.add(PopcornDef(nextPopcornId++, cursorX + 215f, highY - 42f))
                    popcorn.add(PopcornDef(nextPopcornId++, cursorX + 265f, highY - 42f))

                    // Low road spikes so player can either bounce high or jump over spikes cleanly
                    spikes.add(SpikeDef(cursorX + 150f, currentFloorY - 26f, 64f))
                    cursorX += baseW
                }

                else -> {
                    // Two-tier rhythmic spike + enemy gauntlet
                    val gap = (84f + difficulty * 46f).coerceAtMost(132f)
                    cursorX += gap
                    val tierY = (currentFloorY - 58f).coerceIn(280f, GROUND_Y)
                    val tierW = 290f
                    platforms.add(PlatformDef(cursorX, tierY, tierW, FLOOR_HEIGHT))

                    spikes.add(SpikeDef(cursorX + 66f, tierY - 26f, 48f))
                    val eType = pickEnemyType(worldIndex, rng, stage)
                    enemies.add(
                        EnemySpawnDef(
                            x = cursorX + 210f,
                            y = if (eType == EnemyType.NEON_DRONE) tierY - 88f else tierY - 34f,
                            patrolMinX = cursorX + 135f,
                            patrolMaxX = cursorX + tierW - 26f,
                            type = eType
                        )
                    )
                    popcorn.add(PopcornDef(nextPopcornId++, cursorX + 90f, tierY - 96f))
                    popcorn.add(PopcornDef(nextPopcornId++, cursorX + 210f, tierY - 82f))
                    currentFloorY = tierY
                    cursorX += tierW
                }
            }
        }

        // Final goal platform with Giant Popcorn Bucket
        val endGap = 76f
        cursorX += endGap
        val goalPlatY = min(currentFloorY, GROUND_Y)
        val goalPlatW = 280f
        platforms.add(PlatformDef(cursorX, goalPlatY, goalPlatW, FLOOR_HEIGHT))
        val goalX = cursorX + 170f
        val goalY = goalPlatY - 76f
        popcorn.add(PopcornDef(nextPopcornId, cursorX + 75f, goalPlatY - 48f))

        // Guarantee every standard stage has at least 1 enemy to stomp
        if (enemies.isEmpty()) {
            enemies.add(
                EnemySpawnDef(
                    x = cursorX + 60f,
                    y = goalPlatY - 34f,
                    patrolMinX = cursorX + 20f,
                    patrolMaxX = cursorX + 120f,
                    type = pickEnemyType(worldIndex, rng, stage)
                )
            )
        }

        val totalWidth = cursorX + goalPlatW
        val worldName = WorldThemes.forStage(stage).name
        val stageTitle = "$worldName $worldStage"

        return LevelData(
            stageNumber = stage,
            title = stageTitle,
            worldIndex = worldIndex,
            width = totalWidth,
            height = STAGE_HEIGHT,
            spawnX = 76f,
            spawnY = GROUND_Y - 40f,
            goalX = goalX,
            goalY = goalY,
            platforms = platforms,
            spikes = spikes,
            enemies = enemies,
            popcorn = popcorn,
            isBossStage = false
        )
    }

    private fun pickEnemyType(worldIndex: Int, rng: Random, stage: Int): EnemyType {
        if (stage <= 2) return EnemyType.KERNEL_WALKER
        val pool = when (worldIndex) {
            0 -> listOf(EnemyType.KERNEL_WALKER, EnemyType.SALTY_HOPPER)
            1 -> listOf(EnemyType.KERNEL_WALKER, EnemyType.SALTY_HOPPER)
            2 -> listOf(EnemyType.SALTY_HOPPER, EnemyType.CARAMEL_CHARGER, EnemyType.KERNEL_WALKER)
            3 -> listOf(EnemyType.CARAMEL_CHARGER, EnemyType.NEON_DRONE, EnemyType.SALTY_HOPPER)
            4 -> listOf(EnemyType.CHILI_SPIRIT, EnemyType.CARAMEL_CHARGER, EnemyType.NEON_DRONE)
            else -> EnemyType.entries
        }
        return pool[rng.nextInt(pool.size)]
    }

    private fun buildBossStage90(): LevelData {
        val arenaWidth = 1320f
        val platforms = listOf(
            // Main Theater Arena Floor
            PlatformDef(x = 0f, y = GROUND_Y, width = arenaWidth, height = FLOOR_HEIGHT),
            // Left & Right low balconies
            PlatformDef(x = 90f, y = 415f, width = 180f, height = 24f),
            PlatformDef(x = 1050f, y = 415f, width = 180f, height = 24f),
            // Center Royal Vantage Platform
            PlatformDef(x = 515f, y = 325f, width = 290f, height = 24f),
            // Two Bouncy Butter Launch Pads to vault onto the Boss's crown
            PlatformDef(x = 300f, y = GROUND_Y - 14f, width = 84f, height = 14f, type = PlatformType.BOUNCY),
            PlatformDef(x = 936f, y = GROUND_Y - 14f, width = 84f, height = 14f, type = PlatformType.BOUNCY)
        )

        // Subtle side wall corner spikes so player stays active in center arena
        val spikes = listOf(
            SpikeDef(x = 0f, y = GROUND_Y - 26f, width = 44f),
            SpikeDef(x = arenaWidth - 44f, y = GROUND_Y - 26f, width = 44f)
        )

        val popcorn = listOf(
            PopcornDef(1, 180f, 370f),
            PopcornDef(2, 660f, 280f),
            PopcornDef(3, 1140f, 370f),
            PopcornDef(4, 342f, 390f),
            PopcornDef(5, 978f, 390f)
        )

        return LevelData(
            stageNumber = 90,
            title = "Burnt Kernel Emperor",
            worldIndex = 5,
            width = arenaWidth,
            height = STAGE_HEIGHT,
            spawnX = 150f,
            spawnY = GROUND_Y - 40f,
            goalX = arenaWidth * 0.5f,
            goalY = GROUND_Y - 82f,
            platforms = platforms,
            spikes = spikes,
            enemies = emptyList(),
            popcorn = popcorn,
            isBossStage = true
        )
    }
}
