package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "cubey_popcorn_prefs")

class GameProgressRepository(private val context: Context) {

    private object Keys {
        val HIGH_SCORE = intPreferencesKey("high_score")
        val LAST_SCORE = intPreferencesKey("last_score")
        val MAX_UNLOCKED_STAGE = intPreferencesKey("max_unlocked_stage")
        val TOTAL_POPCORN = intPreferencesKey("total_popcorn")
        val UNLOCKED_POWERUPS = stringSetPreferencesKey("unlocked_powerups")
        val EQUIPPED_POWERUPS = stringSetPreferencesKey("equipped_powerups")
        val CLEARED_STAGES = stringSetPreferencesKey("cleared_stages")
        val BOSS_DEFEATED = booleanPreferencesKey("boss_defeated")
        val MUSIC_VOLUME = floatPreferencesKey("music_volume")
        val SFX_VOLUME = floatPreferencesKey("sfx_volume")
        val GRAPHICS_QUALITY = stringPreferencesKey("graphics_quality")
        val PRACTICE_MODE = booleanPreferencesKey("practice_mode_all_unlocked")
    }

    val progressFlow: Flow<GameProgress> = context.dataStore.data.map { prefs ->
        val qualityStr = prefs[Keys.GRAPHICS_QUALITY] ?: GraphicsQuality.MEDIUM.name
        val quality = GraphicsQuality.entries.firstOrNull { it.name == qualityStr }
            ?: GraphicsQuality.MEDIUM

        val cleared = (prefs[Keys.CLEARED_STAGES] ?: emptySet())
            .mapNotNull { it.toIntOrNull() }
            .toSet()

        GameProgress(
            highScore = prefs[Keys.HIGH_SCORE] ?: 0,
            lastScore = prefs[Keys.LAST_SCORE] ?: 0,
            maxUnlockedStage = (prefs[Keys.MAX_UNLOCKED_STAGE] ?: 1).coerceIn(1, 90),
            totalPopcorn = prefs[Keys.TOTAL_POPCORN] ?: 0,
            unlockedPowerUps = prefs[Keys.UNLOCKED_POWERUPS] ?: emptySet(),
            equippedPowerUps = prefs[Keys.EQUIPPED_POWERUPS] ?: emptySet(),
            clearedStages = cleared,
            bossDefeated = prefs[Keys.BOSS_DEFEATED] ?: false,
            musicVolume = (prefs[Keys.MUSIC_VOLUME] ?: 0.65f).coerceIn(0f, 1f),
            sfxVolume = (prefs[Keys.SFX_VOLUME] ?: 0.85f).coerceIn(0f, 1f),
            graphicsQuality = quality,
            practiceModeAllUnlocked = prefs[Keys.PRACTICE_MODE] ?: false
        )
    }

    suspend fun saveAfterGameOver(runScore: Int, collectedPopcornDelta: Int) {
        context.dataStore.edit { prefs ->
            val currentHigh = prefs[Keys.HIGH_SCORE] ?: 0
            if (runScore > currentHigh) {
                prefs[Keys.HIGH_SCORE] = runScore
            }
            prefs[Keys.LAST_SCORE] = runScore
            if (collectedPopcornDelta > 0) {
                val existingPopcorn = prefs[Keys.TOTAL_POPCORN] ?: 0
                prefs[Keys.TOTAL_POPCORN] = existingPopcorn + collectedPopcornDelta
            }
        }
    }

    suspend fun saveStageClear(
        stageNumber: Int,
        runScore: Int,
        collectedPopcornDelta: Int
    ) {
        context.dataStore.edit { prefs ->
            val currentHigh = prefs[Keys.HIGH_SCORE] ?: 0
            if (runScore > currentHigh) {
                prefs[Keys.HIGH_SCORE] = runScore
            }
            val currentMax = prefs[Keys.MAX_UNLOCKED_STAGE] ?: 1
            val nextStage = (stageNumber + 1).coerceAtMost(90)
            if (nextStage > currentMax) {
                prefs[Keys.MAX_UNLOCKED_STAGE] = nextStage
            }
            if (collectedPopcornDelta > 0) {
                val existingPopcorn = prefs[Keys.TOTAL_POPCORN] ?: 0
                prefs[Keys.TOTAL_POPCORN] = existingPopcorn + collectedPopcornDelta
            }
            val existingCleared = prefs[Keys.CLEARED_STAGES] ?: emptySet()
            prefs[Keys.CLEARED_STAGES] = existingCleared + stageNumber.toString()
            if (stageNumber == 90) {
                prefs[Keys.BOSS_DEFEATED] = true
            }
        }
    }

    suspend fun addPopcorn(amount: Int) {
        if (amount <= 0) return
        context.dataStore.edit { prefs ->
            val existing = prefs[Keys.TOTAL_POPCORN] ?: 0
            prefs[Keys.TOTAL_POPCORN] = existing + amount
        }
    }

    suspend fun unlockPowerUp(powerUp: PowerUpType): Boolean {
        var success = false
        context.dataStore.edit { prefs ->
            val popcorn = prefs[Keys.TOTAL_POPCORN] ?: 0
            val unlocked = prefs[Keys.UNLOCKED_POWERUPS] ?: emptySet()
            if (powerUp.id !in unlocked && popcorn >= powerUp.cost) {
                prefs[Keys.TOTAL_POPCORN] = popcorn - powerUp.cost
                prefs[Keys.UNLOCKED_POWERUPS] = unlocked + powerUp.id
                val equipped = prefs[Keys.EQUIPPED_POWERUPS] ?: emptySet()
                prefs[Keys.EQUIPPED_POWERUPS] = equipped + powerUp.id
                success = true
            }
        }
        return success
    }

    suspend fun togglePowerUpEquipped(powerUp: PowerUpType) {
        context.dataStore.edit { prefs ->
            val unlocked = prefs[Keys.UNLOCKED_POWERUPS] ?: emptySet()
            if (powerUp.id !in unlocked) return@edit
            val equipped = prefs[Keys.EQUIPPED_POWERUPS] ?: emptySet()
            prefs[Keys.EQUIPPED_POWERUPS] = if (powerUp.id in equipped) {
                equipped - powerUp.id
            } else {
                equipped + powerUp.id
            }
        }
    }

    suspend fun updateAudioSettings(musicVolume: Float, sfxVolume: Float) {
        context.dataStore.edit { prefs ->
            prefs[Keys.MUSIC_VOLUME] = musicVolume.coerceIn(0f, 1f)
            prefs[Keys.SFX_VOLUME] = sfxVolume.coerceIn(0f, 1f)
        }
    }

    suspend fun updateGraphicsQuality(quality: GraphicsQuality) {
        context.dataStore.edit { prefs ->
            prefs[Keys.GRAPHICS_QUALITY] = quality.name
        }
    }

    suspend fun setPracticeMode(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.PRACTICE_MODE] = enabled
        }
    }

    suspend fun resetProgress() {
        context.dataStore.edit { prefs ->
            val music = prefs[Keys.MUSIC_VOLUME] ?: 0.65f
            val sfx = prefs[Keys.SFX_VOLUME] ?: 0.85f
            val quality = prefs[Keys.GRAPHICS_QUALITY] ?: GraphicsQuality.MEDIUM.name
            prefs.clear()
            prefs[Keys.MUSIC_VOLUME] = music
            prefs[Keys.SFX_VOLUME] = sfx
            prefs[Keys.GRAPHICS_QUALITY] = quality
        }
    }
}
