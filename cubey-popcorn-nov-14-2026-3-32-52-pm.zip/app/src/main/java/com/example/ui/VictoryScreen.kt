package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.GameProgress
import com.example.game.HudSnapshot
import com.example.ui.theme.ButterGold
import com.example.ui.theme.CubeyCyan
import com.example.ui.theme.DeepIndigoSurface
import com.example.ui.theme.ElevatedCardIndigo
import com.example.ui.theme.EmeraldPop
import com.example.ui.theme.KernelCream
import com.example.ui.theme.MidnightTheater
import com.example.ui.theme.MutedLavender

@Composable
fun VictoryScreen(
    hud: HudSnapshot,
    progress: GameProgress,
    onPlayAgainBoss: () -> Unit,
    onStageSelect: () -> Unit,
    onHome: () -> Unit
) {
    BackHandler { onHome() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightTheater)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = ElevatedCardIndigo),
            shape = MaterialTheme.shapes.large,
            modifier = Modifier
                .widthIn(max = 460.dp)
                .fillMaxWidth()
                .border(2.dp, ButterGold, MaterialTheme.shapes.large)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.EmojiEvents,
                    contentDescription = "Grand Victory Trophy",
                    tint = ButterGold,
                    modifier = Modifier.size(64.dp)
                )
                Text(
                    text = "POPCORN CHAMPION!",
                    style = MaterialTheme.typography.headlineLarge,
                    color = ButterGold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Cubey conquered all 90 stages and defeated the Burnt Kernel Emperor!",
                    style = MaterialTheme.typography.bodyLarge,
                    color = KernelCream,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DeepIndigoSurface, MaterialTheme.shapes.small)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Run Score", color = MutedLavender)
                    Text("${hud.score}", color = EmeraldPop, fontWeight = FontWeight.Bold)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DeepIndigoSurface, MaterialTheme.shapes.small)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("All-Time High Score", color = MutedLavender)
                    Text("${maxOf(progress.highScore, hud.highScore)}", color = ButterGold, fontWeight = FontWeight.Bold)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DeepIndigoSurface, MaterialTheme.shapes.small)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Popcorn Bank", color = MutedLavender)
                    Text("${progress.totalPopcorn} 🍿", color = CubeyCyan, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onPlayAgainBoss,
                    colors = ButtonDefaults.buttonColors(containerColor = ButterGold, contentColor = MidnightTheater),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("victory_replay_boss")
                ) {
                    Text("Replay Boss Fight (Stage 90)", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onStageSelect,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("Explore 90 Stages", color = KernelCream)
                }

                OutlinedButton(
                    onClick = onHome,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("Main Menu", color = MutedLavender)
                }
            }
        }
    }
}
