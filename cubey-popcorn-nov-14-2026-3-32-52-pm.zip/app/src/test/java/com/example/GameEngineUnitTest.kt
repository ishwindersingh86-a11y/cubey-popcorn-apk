package com.example

import com.example.audio.ArcadeSoundEngine
import com.example.data.GraphicsQuality
import com.example.game.GameEngine
import com.example.game.LevelGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GameEngineUnitTest {

    @Test
    fun all90StagesGenerateWithValidGeometry() {
        for (stage in 1..90) {
            val level = LevelGenerator.getLevel(stage)
            assertEquals(stage, level.stageNumber)
            assertTrue("Stage $stage should have platforms", level.platforms.isNotEmpty())
            assertTrue("Stage $stage should have popcorn", level.popcorn.isNotEmpty())
            assertTrue("Stage $stage should have spikes", level.spikes.isNotEmpty())
            if (stage == 90) {
                assertTrue(level.isBossStage)
            } else {
                assertFalse(level.isBossStage)
                assertTrue("Stage $stage should have enemies", level.enemies.isNotEmpty())
            }
        }
    }

    @Test
    fun jumpCausesCubeyToSpinInMidAirAndResetOnLand() {
        val engine = createEngine()
        engine.loadStage(1, 0, 0, 0, emptySet(), GraphicsQuality.LOW)

        // Settle Cubey onto starting platform
        repeat(30) { engine.step(0.016f, 800f, 640f) }
        assertTrue(engine.onGround)
        assertFalse(engine.isSpinningJump)

        // Press jump button and measure full higher jump arc
        val startY = engine.playerY
        var highestY = startY
        engine.onJumpPressed()
        repeat(35) {
            engine.step(0.016f, 800f, 640f)
            if (engine.playerY < highestY) highestY = engine.playerY
        }
        assertFalse(engine.onGround)
        assertTrue(engine.isSpinningJump)
        assertTrue("Cubey should spin while jumping", engine.spinAngle != 0f)
        assertTrue("Cubey should jump significantly higher", startY - highestY > 180f)

        // Let Cubey land back on ground
        repeat(45) { engine.step(0.016f, 800f, 640f) }
        assertTrue(engine.onGround)
        assertFalse(engine.isSpinningJump)
        assertEquals(0f, engine.spinAngle, 0.01f)
    }

    @Test
    fun stompingEnemyIncreasesScoreByOneAndSideTouchHurts() {
        val engine = createEngine()
        engine.loadStage(1, 0, 0, 0, emptySet(), GraphicsQuality.LOW)

        val enemy = engine.enemies.first()
        // Position Cubey directly above enemy falling down
        engine.playerX = enemy.x
        engine.playerY = enemy.y - GameEngine.PLAYER_SIZE - 4f
        engine.playerVx = 0f
        engine.playerVy = 250f

        engine.step(0.02f, 800f, 640f)
        assertFalse("Enemy should be defeated on stomp", enemy.alive)
        assertEquals("Score should increase by 1 on enemy stomp", 1, engine.score)
    }

    @Test
    fun spikeKillsAndRestartsLevelAndTriggersGameOverWhenOutOfHearts() {
        var gameOverScore = -1
        val engine = GameEngine(
            soundEngine = ArcadeSoundEngine(),
            onStageCleared = { _, _, _ -> },
            onGameOver = { s, _ -> gameOverScore = s },
            onHudUpdated = {}
        )
        engine.loadStage(1, currentScore = 4, savedHighScore = 2, savedPopcorn = 10, equippedPowerUps = emptySet(), quality = GraphicsQuality.LOW)
        assertEquals(3, engine.hearts)

        val spike = engine.level.spikes.first()
        // Drop onto spike -> loses 1 heart, restarts current level after 0.45s
        engine.playerX = spike.x + 6f
        engine.playerY = spike.y - GameEngine.PLAYER_SIZE + 10f
        engine.step(0.016f, 800f, 640f)
        assertEquals(2, engine.hearts)
        assertTrue(engine.isPlayerDyingFromSpike())

        // Advance past restart delay -> player returns to spawn
        repeat(35) { engine.step(0.016f, 800f, 640f) }
        assertFalse(engine.isPlayerDyingFromSpike())
        assertEquals(engine.level.spawnX, engine.playerX, 1f)

        // Drain remaining 2 hearts on spikes -> Game Over saves score
        repeat(2) {
            engine.playerX = spike.x + 6f
            engine.playerY = spike.y - GameEngine.PLAYER_SIZE + 10f
            engine.step(0.016f, 800f, 640f)
            repeat(35) { engine.step(0.016f, 800f, 640f) }
        }
        assertEquals(0, engine.hearts)
        assertEquals(4, gameOverScore)
    }

    @Test
    fun stage90BossHasLong24HpFightAndTakesCrownStompDamage() {
        val engine = createEngine()
        engine.loadStage(90, 0, 0, 0, emptySet(), GraphicsQuality.MEDIUM)
        val boss = engine.boss
        assertNotNull(boss)
        assertEquals(24, boss!!.hp)

        engine.playerX = boss.x + 30f
        engine.playerY = boss.y - GameEngine.PLAYER_SIZE - 2f
        engine.playerVy = 280f
        repeat(3) { engine.step(0.02f, 960f, 640f) }

        assertEquals(23, boss.hp)
        assertEquals(1, engine.score)
    }

    private fun createEngine(): GameEngine {
        return GameEngine(
            soundEngine = ArcadeSoundEngine(),
            onStageCleared = { _, _, _ -> },
            onGameOver = { _, _ -> },
            onHudUpdated = {}
        )
    }
}
