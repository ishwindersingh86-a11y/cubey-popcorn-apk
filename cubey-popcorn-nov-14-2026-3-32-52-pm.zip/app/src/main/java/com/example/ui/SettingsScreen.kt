package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.GameProgress
import com.example.data.GraphicsQuality
import com.example.ui.theme.ButterGold
import com.example.ui.theme.CinemaCrimson
import com.example.ui.theme.CubeyCyan
import com.example.ui.theme.ElevatedCardIndigo
import com.example.ui.theme.KernelCream
import com.example.ui.theme.MidnightTheater
import com.example.ui.theme.MutedLavender
import com.example.ui.theme.OutlineIndigo
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    progress: GameProgress,
    onAudioChanged: (musicVolume: Float, sfxVolume: Float, previewSfx: Boolean) -> Unit,
    onGraphicsQualityChanged: (GraphicsQuality) -> Unit,
    onPracticeModeChanged: (Boolean) -> Unit,
    onResetProgress: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var showResetDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightTheater)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("settings_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = KernelCream
                )
            }
            Text(
                text = "SETTINGS",
                style = MaterialTheme.typography.headlineMedium,
                color = ButterGold
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Audio Settings Card
            Card(
                colors = CardDefaults.cardColors(containerColor = ElevatedCardIndigo),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlineIndigo, MaterialTheme.shapes.medium)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Audio Levels",
                        style = MaterialTheme.typography.titleLarge,
                        color = KernelCream
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.MusicNote,
                            contentDescription = "Background Music Volume",
                            tint = ButterGold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Background Music",
                            style = MaterialTheme.typography.titleMedium,
                            color = KernelCream,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${(progress.musicVolume * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            color = ButterGold
                        )
                    }
                    Slider(
                        value = progress.musicVolume,
                        onValueChange = { newMusic ->
                            onAudioChanged(newMusic, progress.sfxVolume, false)
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = ButterGold,
                            activeTrackColor = ButterGold
                        ),
                        modifier = Modifier.testTag("music_volume_slider")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.GraphicEq,
                            contentDescription = "Sound Effects Volume",
                            tint = CubeyCyan
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Sound Effects",
                            style = MaterialTheme.typography.titleMedium,
                            color = KernelCream,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${(progress.sfxVolume * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            color = CubeyCyan
                        )
                    }
                    Slider(
                        value = progress.sfxVolume,
                        onValueChange = { newSfx ->
                            onAudioChanged(progress.musicVolume, newSfx, false)
                        },
                        onValueChangeFinished = {
                            onAudioChanged(progress.musicVolume, progress.sfxVolume, true)
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = CubeyCyan,
                            activeTrackColor = CubeyCyan
                        ),
                        modifier = Modifier.testTag("sfx_volume_slider")
                    )
                }
            }

            // Graphics Quality Settings Card (Android 5.1.1+ Smooth Performance)
            Card(
                colors = CardDefaults.cardColors(containerColor = ElevatedCardIndigo),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlineIndigo, MaterialTheme.shapes.medium)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Speed,
                            contentDescription = "Graphics Quality",
                            tint = CubeyCyan
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Graphics Quality",
                            style = MaterialTheme.typography.titleLarge,
                            color = KernelCream
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tune visuals for smooth 60 FPS on Android 5.1.1+ devices.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedLavender
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    GraphicsQuality.entries.forEach { tier ->
                        val selected = progress.graphicsQuality == tier
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(
                                    width = 1.5.dp,
                                    color = if (selected) CubeyCyan else OutlineIndigo,
                                    shape = MaterialTheme.shapes.small
                                )
                                .clickable { onGraphicsQualityChanged(tier) }
                                .padding(10.dp)
                                .testTag("graphics_${tier.name.lowercase()}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selected,
                                onClick = { onGraphicsQualityChanged(tier) }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = tier.label,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (selected) CubeyCyan else KernelCream
                                )
                                Text(
                                    text = tier.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MutedLavender
                                )
                            }
                        }
                    }
                }
            }

            // Practice Mode + Reset Card
            Card(
                colors = CardDefaults.cardColors(containerColor = ElevatedCardIndigo),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlineIndigo, MaterialTheme.shapes.medium)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Unlock All 90 Stages (Practice)",
                                style = MaterialTheme.typography.titleMedium,
                                color = KernelCream
                            )
                            Text(
                                text = "Play any stage including the Stage 90 Boss anytime.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MutedLavender
                            )
                        }
                        Switch(
                            checked = progress.practiceModeAllUnlocked,
                            onCheckedChange = onPracticeModeChanged
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedButton(
                        onClick = { showResetDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reset_progress_button")
                    ) {
                        Text("Reset High Score & Saved Progress", color = CinemaCrimson)
                    }
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset Progress?") },
            text = {
                Text("This clears your High Score (${progress.highScore}), Popcorn bank, Power-Ups, and Stage unlocks.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetDialog = false
                        onResetProgress()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaCrimson)
                ) {
                    Text("Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
