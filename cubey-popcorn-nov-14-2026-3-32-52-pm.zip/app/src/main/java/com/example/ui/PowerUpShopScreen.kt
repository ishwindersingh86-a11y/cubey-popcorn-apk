package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.KeyboardDoubleArrowUp
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.GameProgress
import com.example.data.PowerUpType
import com.example.ui.theme.ButterGold
import com.example.ui.theme.CubeyCyan
import com.example.ui.theme.ElevatedCardIndigo
import com.example.ui.theme.EmeraldPop
import com.example.ui.theme.KernelCream
import com.example.ui.theme.MidnightTheater
import com.example.ui.theme.MutedLavender
import com.example.ui.theme.OutlineIndigo

@Composable
fun PowerUpShopScreen(
    progress: GameProgress,
    onUnlockPowerUp: (PowerUpType) -> Unit,
    onToggleEquipped: (PowerUpType) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightTheater)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("shop_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = KernelCream
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "POPCORN POWER-UPS",
                    style = MaterialTheme.typography.headlineMedium,
                    color = ButterGold
                )
                Text(
                    text = "Spend popcorn collected in stages to unlock special abilities!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedLavender
                )
            }
            Surface(
                color = ButterGold.copy(alpha = 0.18f),
                shape = RoundedCornerShape(50),
                modifier = Modifier.border(1.dp, ButterGold, RoundedCornerShape(50))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Star,
                        contentDescription = "Total Popcorn",
                        tint = ButterGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${progress.totalPopcorn}",
                        style = MaterialTheme.typography.titleMedium,
                        color = ButterGold
                    )
                }
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(PowerUpType.entries, key = { it.id }) { powerUp ->
                val unlocked = progress.isPowerUpUnlocked(powerUp)
                val equipped = progress.isPowerUpEquipped(powerUp)
                val canAfford = progress.totalPopcorn >= powerUp.cost

                val icon = when (powerUp) {
                    PowerUpType.DOUBLE_JUMP -> Icons.Filled.KeyboardDoubleArrowUp
                    PowerUpType.BUTTER_SHIELD -> Icons.Filled.Shield
                    PowerUpType.POPCORN_MAGNET -> Icons.Filled.AutoAwesome
                    PowerUpType.SPEED_KERNEL -> Icons.Filled.Bolt
                    PowerUpType.SUPER_STOMP -> Icons.Filled.Star
                    PowerUpType.EXTRA_HEART -> Icons.Filled.Favorite
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = ElevatedCardIndigo),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.5.dp,
                            color = if (equipped) EmeraldPop else OutlineIndigo,
                            shape = MaterialTheme.shapes.medium
                        )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = if (unlocked) CubeyCyan.copy(alpha = 0.2f) else MidnightTheater,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.size(52.dp)
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = powerUp.title,
                                tint = if (unlocked) CubeyCyan else ButterGold,
                                modifier = Modifier.padding(12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = powerUp.title,
                                style = MaterialTheme.typography.titleLarge,
                                color = KernelCream
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = powerUp.subtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MutedLavender
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        if (unlocked) {
                            if (equipped) {
                                Button(
                                    onClick = { onToggleEquipped(powerUp) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = EmeraldPop,
                                        contentColor = MidnightTheater
                                    ),
                                    modifier = Modifier.testTag("toggle_${powerUp.id}")
                                ) {
                                    Text("ON")
                                }
                            } else {
                                OutlinedButton(
                                    onClick = { onToggleEquipped(powerUp) },
                                    modifier = Modifier.testTag("toggle_${powerUp.id}")
                                ) {
                                    Text("OFF", color = KernelCream)
                                }
                            }
                        } else {
                            Button(
                                onClick = { onUnlockPowerUp(powerUp) },
                                enabled = canAfford,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ButterGold,
                                    contentColor = MidnightTheater
                                ),
                                modifier = Modifier.testTag("unlock_${powerUp.id}")
                            ) {
                                Text("${powerUp.cost} 🍿")
                            }
                        }
                    }
                }
            }
        }
    }
}
