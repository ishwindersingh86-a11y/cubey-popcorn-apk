package com.example.game

enum class PlatformType {
    SOLID,
    MOVING_H,
    MOVING_V,
    BOUNCY
}

enum class SpikeDirection {
    UP,
    DOWN
}

enum class EnemyType {
    KERNEL_WALKER,
    SALTY_HOPPER,
    CARAMEL_CHARGER,
    NEON_DRONE,
    CHILI_SPIRIT
}

data class PlatformDef(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val type: PlatformType = PlatformType.SOLID,
    val moveRange: Float = 0f,
    val moveSpeed: Float = 1.4f
)

data class SpikeDef(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float = 26f,
    val direction: SpikeDirection = SpikeDirection.UP
)

data class EnemySpawnDef(
    val x: Float,
    val y: Float,
    val patrolMinX: Float,
    val patrolMaxX: Float,
    val type: EnemyType
)

data class PopcornDef(
    val id: Int,
    val x: Float,
    val y: Float
)

data class LevelData(
    val stageNumber: Int,
    val title: String,
    val worldIndex: Int,
    val width: Float,
    val height: Float,
    val spawnX: Float,
    val spawnY: Float,
    val goalX: Float,
    val goalY: Float,
    val platforms: List<PlatformDef>,
    val spikes: List<SpikeDef>,
    val enemies: List<EnemySpawnDef>,
    val popcorn: List<PopcornDef>,
    val isBossStage: Boolean = false
)

enum class BossActionState {
    PATROL,
    LEAP_UP,
    SLAM_RECOVERY,
    DASH_TELEGRAPH,
    DASH_CHARGE,
    PHASE_TRANSITION
}

enum class HazardType {
    SHOCKWAVE,
    BUTTER_BOMB,
    TEMP_SPIKE
}
