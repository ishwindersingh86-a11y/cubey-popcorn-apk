package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameProgress
import com.example.game.WorldThemes
import com.example.ui.theme.ButterGold
import com.example.ui.theme.CinemaCrimson
import com.example.ui.theme.CubeyCyan
import com.example.ui.theme.DeepIndigoSurface
import com.example.ui.theme.ElevatedCardIndigo
import com.example.ui.theme.EmeraldPop
import com.example.ui.theme.KernelCream
import com.example.ui.theme.MidnightTheater
import com.example.ui.theme.MutedLavender
import com.example.ui.theme.OutlineIndigo

@Composable
fun StageSelectScreen(
    progress: GameProgress,
    onStageSelected: (Int) -> Unit,
    onTogglePracticeMode: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val initialWorld = ((progress.maxUnlockedStage - 1) / 15).coerceIn(0, 5)
    var selectedWorldIndex by remember { mutableIntStateOf(initialWorld) }
    val selectedWorld = WorldThemes.worlds[selectedWorldIndex]
    val stageStart = selectedWorldIndex * 15 + 1
    val stagesInWorld = (stageStart until stageStart + 15).toList()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightTheater)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("stage_select_back")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = KernelCream
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "90 STAGE JOURNEY",
                    style = MaterialTheme.typography.headlineMedium,
                    color = ButterGold
                )
                Text(
                    text = selectedWorld.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedLavender
                )
            }
        }

        // Practice Mode Toggle Bar (lets players jump straight to any stage or Boss 90!)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .clip(MaterialTheme.shapes.medium)
                .background(ElevatedCardIndigo)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Practice Mode (Unlock All 90 Stages)",
                    style = MaterialTheme.typography.titleMedium,
                    color = KernelCream
                )
                Text(
                    text = "Jump to any world or test the Stage 90 Boss Fight anytime",
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                    color = MutedLavender
                )
            }
            Switch(
                checked = progress.practiceModeAllUnlocked,
                onCheckedChange = onTogglePracticeMode,
                modifier = Modifier.testTag("practice_mode_switch")
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // World Selector Tabs (6 Worlds x 15 Stages = 90 Stages)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            WorldThemes.worlds.forEachIndexed { idx, world ->
                val isSelected = idx == selectedWorldIndex
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedWorldIndex = idx },
                    label = {
                        Text(
                            text = "W${idx + 1}: ${world.name}",
                            style = MaterialTheme.typography.labelLarge
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = world.accentColor,
                        selectedLabelColor = MidnightTheater,
                        containerColor = DeepIndigoSurface,
                        labelColor = KernelCream
                    ),
                    modifier = Modifier.testTag("world_tab_${idx + 1}")
                )
            }
        }

        // 15-Stage Grid for Selected World
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 92.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(stagesInWorld, key = { it }) { stageNum ->
                val unlocked = progress.isStageUnlocked(stageNum)
                val cleared = stageNum in progress.clearedStages
                val isBoss = stageNum == 90

                val borderColor = when {
                    isBoss && unlocked -> CinemaCrimson
                    cleared -> EmeraldPop
                    unlocked -> selectedWorld.accentColor
                    else -> OutlineIndigo
                }

                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            if (isBoss) CinemaCrimson.copy(alpha = 0.22f)
                            else if (unlocked) ElevatedCardIndigo
                            else DeepIndigoSurface.copy(alpha = 0.6f)
                        )
                        .border(2.dp, borderColor, RoundedCornerShape(16.dp))
                        .clickable(enabled = unlocked) { onStageSelected(stageNum) }
                        .testTag("stage_tile_$stageNum"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (isBoss) {
                            Icon(
                                imageVector = if (unlocked) Icons.Filled.Warning else Icons.Filled.Lock,
                                contentDescription = "Boss Stage 90",
                                tint = if (unlocked) ButterGold else MutedLavender,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "90",
                                style = MaterialTheme.typography.headlineMedium,
                                color = if (unlocked) ButterGold else MutedLavender
                            )
                            Text(
                                text = "BOSS",
                                style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
                                color = if (unlocked) CinemaCrimson else MutedLavender
                            )
                        } else {
                            Text(
                                text = "$stageNum",
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (unlocked) KernelCream else MutedLavender.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            when {
                                !unlocked -> Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = "Locked",
                                    tint = MutedLavender.copy(alpha = 0.5f),
                                    modifier = Modifier.size(16.dp)
                                )
                                cleared -> Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Cleared",
                                    tint = EmeraldPop,
                                    modifier = Modifier.size(18.dp)
                                )
                                else -> Icon(
                                    imageVector = Icons.Filled.EmojiEvents,
                                    contentDescription = "Unlocked",
                                    tint = CubeyCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
