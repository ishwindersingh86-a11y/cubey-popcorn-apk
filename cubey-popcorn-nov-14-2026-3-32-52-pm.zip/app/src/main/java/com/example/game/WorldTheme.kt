package com.example.game

import androidx.compose.ui.graphics.Color

data class WorldTheme(
    val worldIndex: Int,
    val name: String,
    val subtitle: String,
    val skyTop: Color,
    val skyBottom: Color,
    val hillFar: Color,
    val hillNear: Color,
    val platformBody: Color,
    val platformTop: Color,
    val platformBorder: Color,
    val spikeColor: Color,
    val accentColor: Color
)

object WorldThemes {
    val worlds: List<WorldTheme> = listOf(
        WorldTheme(
            worldIndex = 0,
            name = "Butter Meadow",
            subtitle = "Stages 1–15 • Sunny Cinema Hills",
            skyTop = Color(0xFF142850),
            skyBottom = Color(0xFF27496D),
            hillFar = Color(0xFF1E3B63),
            hillNear = Color(0xFF183052),
            platformBody = Color(0xFF8B5E3C),
            platformTop = Color(0xFF38D399),
            platformBorder = Color(0xFF5C3D24),
            spikeColor = Color(0xFFFF4757),
            accentColor = Color(0xFFFFC83D)
        ),
        WorldTheme(
            worldIndex = 1,
            name = "Salty Caverns",
            subtitle = "Stages 16–30 • Crystal Kernel Depths",
            skyTop = Color(0xFF120E2E),
            skyBottom = Color(0xFF231942),
            hillFar = Color(0xFF2B2154),
            hillNear = Color(0xFF1C153B),
            platformBody = Color(0xFF3A4068),
            platformTop = Color(0xFF38BDF8),
            platformBorder = Color(0xFF232847),
            spikeColor = Color(0xFFFF5E7E),
            accentColor = Color(0xFF38BDF8)
        ),
        WorldTheme(
            worldIndex = 2,
            name = "Caramel Factory",
            subtitle = "Stages 31–45 • Golden Kettle Works",
            skyTop = Color(0xFF2B140C),
            skyBottom = Color(0xFF4A2511),
            hillFar = Color(0xFF3E1E0E),
            hillNear = Color(0xFF2D1509),
            platformBody = Color(0xFF6B3F24),
            platformTop = Color(0xFFFFA94D),
            platformBorder = Color(0xFF472714),
            spikeColor = Color(0xFFFF4D4D),
            accentColor = Color(0xFFFFA94D)
        ),
        WorldTheme(
            worldIndex = 3,
            name = "Neon Cinema",
            subtitle = "Stages 46–60 • Electric Arcade Screen",
            skyTop = Color(0xFF0E0B26),
            skyBottom = Color(0xFF1F1247),
            hillFar = Color(0xFF2A1859),
            hillNear = Color(0xFF190E3B),
            platformBody = Color(0xFF22254C),
            platformTop = Color(0xFFE040FB),
            platformBorder = Color(0xFF151736),
            spikeColor = Color(0xFFFF2E63),
            accentColor = Color(0xFF00F5D4)
        ),
        WorldTheme(
            worldIndex = 4,
            name = "Chili Volcano",
            subtitle = "Stages 61–75 • Molten Pepper Halls",
            skyTop = Color(0xFF24090E),
            skyBottom = Color(0xFF4B1219),
            hillFar = Color(0xFF3C0E14),
            hillNear = Color(0xFF2A090D),
            platformBody = Color(0xFF3E262A),
            platformTop = Color(0xFFFF6B35),
            platformBorder = Color(0xFF231316),
            spikeColor = Color(0xFFFFD166),
            accentColor = Color(0xFFFF6B35)
        ),
        WorldTheme(
            worldIndex = 5,
            name = "Grand Theater",
            subtitle = "Stages 76–90 • Burnt Kernel Finale",
            skyTop = Color(0xFF140D24),
            skyBottom = Color(0xFF30193F),
            hillFar = Color(0xFF281538),
            hillNear = Color(0xFF1B0E26),
            platformBody = Color(0xFF432344),
            platformTop = Color(0xFFFFC83D),
            platformBorder = Color(0xFF29132A),
            spikeColor = Color(0xFFFF3860),
            accentColor = Color(0xFFFFC83D)
        )
    )

    fun forStage(stageNumber: Int): WorldTheme {
        val index = ((stageNumber - 1) / 15).coerceIn(0, worlds.lastIndex)
        return worlds[index]
    }
}
