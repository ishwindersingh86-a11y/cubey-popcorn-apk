package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GameProgress
import com.example.ui.theme.ButterGold
import com.example.ui.theme.CubeyCyan
import com.example.ui.theme.DeepIndigoSurface
import com.example.ui.theme.ElevatedCardIndigo
import com.example.ui.theme.EmeraldPop
import com.example.ui.theme.KernelCream
import com.example.ui.theme.MidnightTheater
import com.example.ui.theme.MutedLavender
import com.example.ui.theme.OutlineIndigo

@Composable
fun TitleScreen(
    progress: GameProgress,
    onPlayClick: () -> Unit,
    onStageSelectClick: () -> Unit,
    onShopClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(MidnightTheater, DeepIndigoSurface, MidnightTheater)
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier.widthIn(max = 600.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Ad-free Arcade Marquee Pill
                Surface(
                    color = EmeraldPop.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.border(1.dp, EmeraldPop.copy(alpha = 0.5f), RoundedCornerShape(50))
                ) {
                    Text(
                        text = "AD-FREE • 90 STAGES • OFFLINE READY",
                        style = MaterialTheme.typography.labelMedium,
                        color = EmeraldPop,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "CUBEY'S POPCORN",
                    style = MaterialTheme.typography.displayLarge.copy(fontSize = 36.sp),
                    color = ButterGold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Stomp enemies, dodge spikes, collect popcorn & defeat the Stage 90 Emperor!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedLavender,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Hero Art Card
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = ElevatedCardIndigo),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(2.dp, OutlineIndigo, MaterialTheme.shapes.large)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_title_hero),
                        contentDescription = "Cubey leaping toward a glowing cinema bucket of popcorn",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .clip(MaterialTheme.shapes.large)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Stats Row: High Score, Popcorn, Stage Progress
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatBadgeCard(
                        icon = Icons.Filled.EmojiEvents,
                        label = "HIGH SCORE",
                        value = progress.highScore.toString(),
                        accent = ButterGold,
                        modifier = Modifier.weight(1f)
                    )
                    StatBadgeCard(
                        icon = Icons.Filled.Star,
                        label = "POPCORN",
                        value = progress.totalPopcorn.toString(),
                        accent = CubeyCyan,
                        modifier = Modifier.weight(1f)
                    )
                    StatBadgeCard(
                        icon = Icons.Filled.GridView,
                        label = "STAGE",
                        value = "${progress.maxUnlockedStage}/90",
                        accent = EmeraldPop,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Primary Play / Resume CTA
                Button(
                    onClick = onPlayClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ButterGold,
                        contentColor = MidnightTheater
                    ),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("play_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (progress.maxUnlockedStage > 1) {
                            "CONTINUE STAGE ${progress.maxUnlockedStage}"
                        } else {
                            "START STAGE 1"
                        },
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Secondary Actions Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onStageSelectClick,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("stages_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.GridView,
                            contentDescription = null,
                            tint = CubeyCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("90 Stages", color = KernelCream)
                    }

                    OutlinedButton(
                        onClick = onShopClick,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("powerups_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = ButterGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Power-Ups", color = KernelCream)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = onSettingsClick,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = null,
                        tint = MutedLavender,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Audio & Graphics Settings", color = KernelCream)
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Controls Quick Hint
                Card(
                    colors = CardDefaults.cardColors(containerColor = ElevatedCardIndigo.copy(alpha = 0.7f)),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Controls: JUMP button on Left (spin jump!) • LEFT & RIGHT buttons on Right",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedLavender,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun StatBadgeCard(
    icon: ImageVector,
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ElevatedCardIndigo),
        shape = MaterialTheme.shapes.medium,
        modifier = modifier.border(1.dp, OutlineIndigo, MaterialTheme.shapes.medium)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accent,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                color = KernelCream
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
                color = MutedLavender
            )
        }
    }
}
