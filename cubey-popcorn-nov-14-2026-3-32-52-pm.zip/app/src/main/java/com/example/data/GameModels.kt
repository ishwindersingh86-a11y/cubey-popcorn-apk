package com.example.data

enum class GraphicsQuality(
    val label: String,
    val description: String
) {
    LOW(
        label = "Low (Legacy 5.1+)",
        description = "Disables parallax layers, gradients, and particle bursts for maximum FPS on older devices."
    ),
    MEDIUM(
        label = "Medium (Balanced)",
        description = "Smooth single-layer backdrop with clean particles and balanced effects."
    ),
    HIGH(
        label = "High (Full Arcade)",
        description = "Full multi-layer parallax, glowing gradients, spin trails, and rich popcorn bursts."
    )
}

enum class PowerUpType(
    val id: String,
    val title: String,
    val subtitle: String,
    val cost: Int
) {
    DOUBLE_JUMP(
        id = "double_jump",
        title = "Double Spin Jump",
        subtitle = "Tap Jump in mid-air for an extra somersault boost.",
        cost = 12
    ),
    BUTTER_SHIELD(
        id = "butter_shield",
        title = "Butter Shield",
        subtitle = "Absorbs 1 enemy hit per stage before taking heart damage.",
        cost = 25
    ),
    POPCORN_MAGNET(
        id = "popcorn_magnet",
        title = "Popcorn Magnet",
        subtitle = "Pulls nearby popcorn kernels straight toward Cubey.",
        cost = 40
    ),
    SPEED_KERNEL(
        id = "speed_kernel",
        title = "Turbo Kernel",
        subtitle = "Boosts Cubey's movement speed and air control by 20%.",
        cost = 60
    ),
    SUPER_STOMP(
        id = "super_stomp",
        title = "Super Stomp",
        subtitle = "Higher enemy bounce and deals 2x damage to the Stage 90 Boss.",
        cost = 85
    ),
    EXTRA_HEART(
        id = "extra_heart",
        title = "Extra Heart",
        subtitle = "Increases Cubey's maximum hearts from 3 to 4.",
        cost = 115
    )
}

data class GameProgress(
    val highScore: Int = 0,
    val lastScore: Int = 0,
    val maxUnlockedStage: Int = 1,
    val totalPopcorn: Int = 0,
    val unlockedPowerUps: Set<String> = emptySet(),
    val equippedPowerUps: Set<String> = emptySet(),
    val clearedStages: Set<Int> = emptySet(),
    val bossDefeated: Boolean = false,
    val musicVolume: Float = 0.65f,
    val sfxVolume: Float = 0.85f,
    val graphicsQuality: GraphicsQuality = GraphicsQuality.MEDIUM,
    val practiceModeAllUnlocked: Boolean = false
) {
    fun isStageUnlocked(stageNumber: Int): Boolean {
        return practiceModeAllUnlocked || stageNumber <= maxUnlockedStage
    }

    fun isPowerUpUnlocked(type: PowerUpType): Boolean = type.id in unlockedPowerUps
    fun isPowerUpEquipped(type: PowerUpType): Boolean = type.id in equippedPowerUps && isPowerUpUnlocked(type)
}
