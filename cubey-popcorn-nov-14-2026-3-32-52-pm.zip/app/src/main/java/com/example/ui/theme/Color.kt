package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MidnightTheater = Color(0xFF101326)
val DeepIndigoSurface = Color(0xFF1A1F3D)
val ElevatedCardIndigo = Color(0xFF242B52)
val CubeyCyan = Color(0xFF22E4FF)
val CubeyCyanDark = Color(0xFF0099CC)
val ButterGold = Color(0xFFFFC83D)
val ButterGoldLight = Color(0xFFFFE58F)
val CinemaCrimson = Color(0xFFFF4757)
val EmeraldPop = Color(0xFF2ED573)
val CaramelOrange = Color(0xFFFF8C42)
val NeonViolet = Color(0xFF9B5DE5)
val KernelCream = Color(0xFFFFF8E7)
val MutedLavender = Color(0xFFB3BAE0)
val OutlineIndigo = Color(0xFF3E477A)
