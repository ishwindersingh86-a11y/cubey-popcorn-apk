package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

enum class SoundEffect {
    JUMP,
    DOUBLE_JUMP,
    STOMP,
    POPCORN,
    HURT,
    SPIKE_DEATH,
    POWERUP,
    BOSS_HIT,
    BOSS_ROAR,
    STAGE_CLEAR,
    GAME_OVER
}

/**
 * Offline procedural audio engine synthesizing a playful, bouncy Bounce-Tales-inspired
 * G-major flute/marimba melody with oom-pah bass, off-beat chord plucks, and light percussion,
 * plus crisp retro sound effects on Android 5.1.1 (API 22) and above.
 */
class ArcadeSoundEngine {

    private companion object {
        const val SAMPLE_RATE = 22050
        const val CHUNK_SAMPLES = 512
    }

    private data class ActiveSfx(
        val buffer: FloatArray,
        var index: Int = 0
    )

    @Volatile var musicVolume: Float = 0.65f
    @Volatile var sfxVolume: Float = 0.85f
    @Volatile var isBossMusic: Boolean = false
    @Volatile private var isPlaying: Boolean = false
    @Volatile private var isPaused: Boolean = false

    private val pendingSfx = ConcurrentLinkedQueue<ActiveSfx>()
    private val activeSfx = mutableListOf<ActiveSfx>()
    private val sfxBuffers: Map<SoundEffect, FloatArray> = SoundEffect.entries.associateWith {
        synthesizeSfx(it)
    }

    private var audioThread: Thread? = null

    fun start() {
        if (isPlaying) return
        isPlaying = true
        audioThread = Thread({ runAudioLoop() }, "CubeyAudioMixer").apply {
            priority = Thread.NORM_PRIORITY
            isDaemon = true
            start()
        }
    }

    fun setPaused(paused: Boolean) {
        isPaused = paused
    }

    fun playSfx(effect: SoundEffect) {
        if (sfxVolume <= 0.01f || isPaused) return
        val buf = sfxBuffers[effect] ?: return
        if (pendingSfx.size < 10) {
            pendingSfx.add(ActiveSfx(buf))
        }
    }

    fun stop() {
        isPlaying = false
        audioThread?.interrupt()
        audioThread = null
    }

    private fun runAudioLoop() {
        val minBufBytes = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(CHUNK_SAMPLES * 4)

        val track = try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .build()
            AudioTrack(
                attrs,
                format,
                minBufBytes,
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )
        } catch (_: Throwable) {
            null
        } ?: return

        val pcmOut = ShortArray(CHUNK_SAMPLES)
        var sampleClock = 0L
        var leadPhase = 0.0
        var bassPhase = 0.0
        var pluckPhase = 0.0
        var noiseSeed = 0x5A3C19

        try {
            track.play()
            while (isPlaying) {
                if (isPaused || (musicVolume <= 0.01f && pendingSfx.isEmpty() && activeSfx.isEmpty())) {
                    Thread.sleep(25L)
                    continue
                }

                while (true) {
                    val next = pendingSfx.poll() ?: break
                    if (activeSfx.size < 8) {
                        activeSfx.add(next)
                    }
                }

                val mVol = musicVolume * 0.28f
                val sVol = sfxVolume * 0.55f
                val boss = isBossMusic
                // Bouncy ~138 BPM 8th-note grid (~0.109s per 16th/8th step)
                val stepSamples = if (boss) (SAMPLE_RATE * 0.14f).toInt() else (SAMPLE_RATE * 0.175f).toInt()

                for (i in 0 until CHUNK_SAMPLES) {
                    var mix = 0f

                    if (mVol > 0.002f) {
                        val stepIndex = ((sampleClock / stepSamples) % 64L).toInt()
                        val stepPos = (sampleClock % stepSamples).toFloat() / stepSamples.toFloat()

                        val leadFreq = if (boss) bossBounceLead(stepIndex) else bounceTalesLead(stepIndex)
                        val bassFreq = if (boss) bossBounceBass(stepIndex) else bounceTalesBass(stepIndex)
                        val pluckFreq = if (boss) bossBouncePluck(stepIndex) else bounceTalesPluck(stepIndex)

                        // Warm playful flute/marimba lead (sine + gentle 2nd harmonic + rounded attack)
                        if (leadFreq > 0f) {
                            leadPhase += leadFreq / SAMPLE_RATE.toDouble()
                            if (leadPhase >= 1.0) leadPhase -= 1.0
                            val attack = (stepPos * 12f).coerceIn(0f, 1f)
                            val decay = exp((-stepPos * 2.1f).toDouble()).toFloat()
                            val env = attack * decay
                            val flute = (sin(leadPhase * 2.0 * PI) +
                                0.30 * sin(leadPhase * 4.0 * PI) +
                                0.10 * sin(leadPhase * 6.0 * PI)).toFloat() * 0.72f
                            mix += flute * env * 0.52f * mVol
                        }

                        // Bouncy oom-pah bass (warm round sub + triangle octave bounce)
                        if (bassFreq > 0f) {
                            bassPhase += bassFreq / SAMPLE_RATE.toDouble()
                            if (bassPhase >= 1.0) bassPhase -= 1.0
                            val bassEnv = exp((-stepPos * 3.4f).toDouble()).toFloat()
                            val sub = sin(bassPhase * 2.0 * PI).toFloat()
                            val tri = (4.0 * abs(bassPhase - 0.5) - 1.0).toFloat()
                            mix += (sub * 0.65f + tri * 0.35f) * bassEnv * 0.55f * mVol
                        }

                        // Off-beat marimba chord pluck sparkle
                        if (pluckFreq > 0f) {
                            pluckPhase += pluckFreq / SAMPLE_RATE.toDouble()
                            if (pluckPhase >= 1.0) pluckPhase -= 1.0
                            val pluckEnv = exp((-stepPos * 5.2f).toDouble()).toFloat()
                            val marimba = (sin(pluckPhase * 2.0 * PI) + 0.25 * sin(pluckPhase * 4.0 * PI)).toFloat()
                            mix += marimba * pluckEnv * 0.28f * mVol
                        }

                        // Crisp light Bounce-Tales percussion pulse (soft kick on even beats, brush tick on odd)
                        noiseSeed = noiseSeed * 1103515245 + 12345
                        val white = ((noiseSeed shr 16) and 0x7FFF) / 16384f - 1f
                        if (stepIndex % 2 == 0) {
                            // Soft warm kick thump
                            val kickEnv = exp((-stepPos * 11f).toDouble()).toFloat()
                            val kickWave = sin(stepPos * 2.0 * PI * 18.0).toFloat()
                            mix += kickWave * kickEnv * 0.22f * mVol
                        } else {
                            // Light brushed shaker / snare tick
                            val hatEnv = exp((-stepPos * 18f).toDouble()).toFloat()
                            mix += white * hatEnv * 0.12f * mVol
                        }
                    }

                    if (activeSfx.isNotEmpty() && sVol > 0.002f) {
                        var idx = activeSfx.size - 1
                        while (idx >= 0) {
                            val sfx = activeSfx[idx]
                            if (sfx.index < sfx.buffer.size) {
                                mix += sfx.buffer[sfx.index] * sVol
                                sfx.index++
                            } else {
                                activeSfx.removeAt(idx)
                            }
                            idx--
                        }
                    } else if (activeSfx.isNotEmpty()) {
                        activeSfx.clear()
                    }

                    val clamped = mix.coerceIn(-0.98f, 0.98f)
                    pcmOut[i] = (clamped * Short.MAX_VALUE).toInt().toShort()
                    sampleClock++
                }

                track.write(pcmOut, 0, CHUNK_SAMPLES)
            }
        } catch (_: InterruptedException) {
            // Expected on shutdown
        } catch (_: Throwable) {
            // AudioTrack error handled silently to never interrupt gameplay
        } finally {
            try {
                track.stop()
                track.release()
            } catch (_: Throwable) {
            }
        }
    }

    // Playful G-major Bounce-Tales-inspired adventurous bouncy loop (64 steps = 8 bars)
    private fun bounceTalesLead(step: Int): Float {
        val g4 = 392.00f
        val a4 = 440.00f
        val b4 = 493.88f
        val c5 = 523.25f
        val d5 = 587.33f
        val e5 = 659.25f
        val fs5 = 739.99f
        val g5 = 783.99f
        val a5 = 880.00f

        val melody = floatArrayOf(
            // Bar 1-2: G major bouncy hook
            g4, b4, d5, b4,  g5, 0f, e5, d5,
            b4, d5, g5, d5,  e5, d5, b4, a4,
            // Bar 3-4: C major -> D major lift
            c5, e5, g5, e5,  a5, 0f, g5, e5,
            d5, fs5, a5, fs5, g5, 0f, d5, 0f,
            // Bar 5-6: E minor -> C major playful answer
            e5, g5, b4, e5,  d5, b4, g4, b4,
            c5, e5, g5, e5,  d5, c5, b4, a4,
            // Bar 7-8: D7 turnaround -> happy G resolution
            b4, d5, g5, fs5, e5, d5, c5, b4,
            a4, b4, d5, fs5, g5, 0f, g5, 0f
        )
        return melody[step % melody.size]
    }

    private fun bounceTalesBass(step: Int): Float {
        val g2 = 98.00f
        val a2 = 110.00f
        val b2 = 123.47f
        val c3 = 130.81f
        val d3 = 146.83f
        val e3 = 164.81f
        val fs3 = 185.00f
        val g3 = 196.00f

        val bass = floatArrayOf(
            // Oom-pah alternating root & 5th
            g2, 0f, d3, 0f,  g2, 0f, d3, 0f,
            g2, 0f, b2, 0f,  d3, 0f, g2, 0f,
            c3, 0f, g3, 0f,  c3, 0f, g3, 0f,
            d3, 0f, a2, 0f,  g2, 0f, d3, 0f,
            e3, 0f, b2, 0f,  g2, 0f, d3, 0f,
            c3, 0f, g3, 0f,  a2, 0f, d3, 0f,
            g2, 0f, b2, 0f,  c3, 0f, c3, 0f,
            d3, 0f, fs3, 0f, g2, 0f, d3, 0f
        )
        return bass[step % bass.size]
    }

    private fun bounceTalesPluck(step: Int): Float {
        // Light off-beat marimba chord accents
        if (step % 2 == 0) return 0f
        val g4 = 392.00f
        val b4 = 493.88f
        val c5 = 523.25f
        val d5 = 587.33f
        val e5 = 659.25f
        val fs5 = 739.99f
        val plucks = floatArrayOf(
            b4, d5, g4, b4,
            e5, c5, d5, fs5,
            b4, e5, b4, d5,
            e5, c5, d5, b4
        )
        return plucks[(step / 2) % plucks.size]
    }

    // Energetic E-minor Bounce-Tales-styled Boss Battle theme
    private fun bossBounceLead(step: Int): Float {
        val e4 = 329.63f
        val g4 = 392.00f
        val a4 = 440.00f
        val b4 = 493.88f
        val c5 = 523.25f
        val d5 = 587.33f
        val ds5 = 622.25f
        val e5 = 659.25f
        val g5 = 783.99f

        val melody = floatArrayOf(
            e4, g4, b4, e5,  ds5, b4, g4, b4,
            c5, e5, g5, e5,  d5, b4, a4, g4,
            e4, g4, b4, e5,  g5, 0f, e5, d5,
            c5, b4, a4, g4,  b4, ds5, e5, 0f
        )
        return melody[step % melody.size]
    }

    private fun bossBounceBass(step: Int): Float {
        val e2 = 82.41f
        val b2 = 123.47f
        val c3 = 130.81f
        val d3 = 146.83f
        val a2 = 110.00f
        val bass = floatArrayOf(
            e2, 0f, b2, 0f,  e2, 0f, b2, 0f,
            c3, 0f, c3, 0f,  d3, 0f, b2, 0f,
            e2, 0f, b2, 0f,  e2, 0f, d3, 0f,
            c3, 0f, a2, 0f,  b2, 0f, e2, 0f
        )
        return bass[step % bass.size]
    }

    private fun bossBouncePluck(step: Int): Float {
        if (step % 2 == 0) return 0f
        val plucks = floatArrayOf(493.88f, 659.25f, 523.25f, 587.33f, 493.88f, 783.99f, 523.25f, 622.25f)
        return plucks[(step / 2) % plucks.size]
    }

    private fun synthesizeSfx(effect: SoundEffect): FloatArray {
        return when (effect) {
            SoundEffect.JUMP -> sweepTone(durationSec = 0.16f, startHz = 280f, endHz = 760f, square = false)
            SoundEffect.DOUBLE_JUMP -> sweepTone(durationSec = 0.18f, startHz = 440f, endHz = 1040f, square = false)
            SoundEffect.STOMP -> arpeggioTone(floatArrayOf(360f, 540f, 820f), stepSec = 0.045f, square = false)
            SoundEffect.POPCORN -> arpeggioTone(floatArrayOf(680f, 1020f, 1360f), stepSec = 0.04f, square = false)
            SoundEffect.HURT -> sweepTone(durationSec = 0.22f, startHz = 300f, endHz = 110f, square = true)
            SoundEffect.SPIKE_DEATH -> sweepTone(durationSec = 0.30f, startHz = 440f, endHz = 75f, square = true)
            SoundEffect.POWERUP -> arpeggioTone(floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f), stepSec = 0.065f, square = false)
            SoundEffect.BOSS_HIT -> sweepTone(durationSec = 0.20f, startHz = 220f, endHz = 65f, square = true)
            SoundEffect.BOSS_ROAR -> sweepTone(durationSec = 0.38f, startHz = 180f, endHz = 55f, square = true)
            SoundEffect.STAGE_CLEAR -> arpeggioTone(floatArrayOf(392.00f, 493.88f, 587.33f, 783.99f, 987.77f), stepSec = 0.08f, square = false)
            SoundEffect.GAME_OVER -> arpeggioTone(floatArrayOf(392f, 349.23f, 329.63f, 261.63f), stepSec = 0.13f, square = false)
        }
    }

    private fun sweepTone(
        durationSec: Float,
        startHz: Float,
        endHz: Float,
        square: Boolean
    ): FloatArray {
        val count = (SAMPLE_RATE * durationSec).toInt().coerceAtLeast(1)
        val out = FloatArray(count)
        var phase = 0.0
        for (i in 0 until count) {
            val t = i.toFloat() / count.toFloat()
            val freq = startHz + (endHz - startHz) * t
            phase += freq / SAMPLE_RATE.toDouble()
            if (phase >= 1.0) phase -= 1.0
            val wave = if (square) {
                if (phase < 0.5) 1f else -1f
            } else {
                (sin(phase * 2.0 * PI) + 0.25 * sin(phase * 4.0 * PI)).toFloat() * 0.8f
            }
            val env = (1f - t)
            out[i] = wave * env * 0.7f
        }
        return out
    }

    private fun arpeggioTone(
        notes: FloatArray,
        stepSec: Float,
        square: Boolean
    ): FloatArray {
        val stepSamples = (SAMPLE_RATE * stepSec).toInt().coerceAtLeast(1)
        val total = stepSamples * notes.size
        val out = FloatArray(total)
        var phase = 0.0
        for (nIdx in notes.indices) {
            val freq = notes[nIdx]
            for (j in 0 until stepSamples) {
                val i = nIdx * stepSamples + j
                val localT = j.toFloat() / stepSamples.toFloat()
                phase += freq / SAMPLE_RATE.toDouble()
                if (phase >= 1.0) phase -= 1.0
                val wave = if (square) {
                    if (phase < 0.45) 1f else -1f
                } else {
                    (sin(phase * 2.0 * PI) + 0.22 * sin(phase * 4.0 * PI)).toFloat() * 0.82f
                }
                val env = (1f - localT * 0.4f)
                out[i] = wave * env * 0.7f
            }
        }
        return out
    }
}
