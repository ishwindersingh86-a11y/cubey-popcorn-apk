package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ButterGold
import com.example.ui.theme.CubeyCyan
import com.example.ui.theme.DeepIndigoSurface
import com.example.ui.theme.KernelCream

/**
 * Multi-touch arcade controls layout:
 * - JUMP button on the LEFT side of the screen
 * - LEFT & RIGHT directional buttons on the RIGHT side of the screen
 * Uses independent pointerInput scopes so simultaneous Jump + Move works seamlessly.
 */
@Composable
fun TouchControlsOverlay(
    onJumpPressed: () -> Unit,
    onJumpReleased: () -> Unit,
    onLeftChanged: (Boolean) -> Unit,
    onRightChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var jumpDown by remember { mutableStateOf(false) }
    var leftDown by remember { mutableStateOf(false) }
    var rightDown by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        // LEFT SIDE: JUMP BUTTON
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .size(86.dp)
                .clip(CircleShape)
                .background(
                    if (jumpDown) ButterGold else DeepIndigoSurface.copy(alpha = 0.78f)
                )
                .border(
                    width = 3.dp,
                    color = if (jumpDown) KernelCream else ButterGold,
                    shape = CircleShape
                )
                .testTag("jump_button")
                .semantics { contentDescription = "Jump and spin" }
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            val anyPressed = event.changes.any { it.pressed }
                            if (anyPressed != jumpDown) {
                                jumpDown = anyPressed
                                if (anyPressed) onJumpPressed() else onJumpReleased()
                            }
                            event.changes.forEach { it.consume() }
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Filled.KeyboardArrowUp,
                        contentDescription = null,
                        tint = if (jumpDown) DeepIndigoSurface else ButterGold,
                        modifier = Modifier.size(34.dp)
                    )
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null,
                        tint = (if (jumpDown) DeepIndigoSurface else CubeyCyan).copy(alpha = 0.85f),
                        modifier = Modifier
                            .size(16.dp)
                            .align(Alignment.TopEnd)
                    )
                }
                Text(
                    text = "JUMP",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (jumpDown) DeepIndigoSurface else KernelCream
                )
            }
        }

        // RIGHT SIDE: LEFT & RIGHT DIRECTIONAL BUTTONS (multi-touch + thumb-slide friendly)
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            val halfWidth = size.width / 2f
                            var wantLeft = false
                            var wantRight = false
                            for (change in event.changes) {
                                if (change.pressed) {
                                    if (change.position.x < halfWidth) {
                                        wantLeft = true
                                    } else {
                                        wantRight = true
                                    }
                                }
                                change.consume()
                            }
                            if (wantLeft != leftDown) {
                                leftDown = wantLeft
                                onLeftChanged(wantLeft)
                            }
                            if (wantRight != rightDown) {
                                rightDown = wantRight
                                onRightChanged(wantRight)
                            }
                        }
                    }
                },
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DirectionalButton(
                isPressed = leftDown,
                isLeft = true,
                tag = "move_left_button"
            )
            DirectionalButton(
                isPressed = rightDown,
                isLeft = false,
                tag = "move_right_button"
            )
        }
    }
}

@Composable
private fun DirectionalButton(
    isPressed: Boolean,
    isLeft: Boolean,
    tag: String
) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(
                if (isPressed) CubeyCyan else DeepIndigoSurface.copy(alpha = 0.78f)
            )
            .border(
                width = 3.dp,
                color = if (isPressed) KernelCream else CubeyCyan,
                shape = RoundedCornerShape(22.dp)
            )
            .testTag(tag)
            .semantics {
                contentDescription = if (isLeft) "Move Left" else "Move Right"
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (isLeft) {
                Icons.AutoMirrored.Filled.KeyboardArrowLeft
            } else {
                Icons.AutoMirrored.Filled.KeyboardArrowRight
            },
            contentDescription = null,
            tint = if (isPressed) DeepIndigoSurface else KernelCream,
            modifier = Modifier.size(44.dp)
        )
    }
}
