package com.example.game

import androidx.compose.ui.graphics.Color
import com.example.audio.ArcadeSoundEngine
import com.example.audio.SoundEffect
import com.example.data.GraphicsQuality
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

data class ActivePlatform(
    val baseX: Float,
    val baseY: Float,
    val width: Float,
    val height: Float,
    val type: PlatformType,
    val moveRange: Float,
    val moveSpeed: Float,
    var x: Float = baseX,
    var y: Float = baseY,
    var prevX: Float = baseX,
    var prevY: Float = baseY,
    var phase: Float = 0f
)

data class ActiveEnemy(
    val id: Int,
    var x: Float,
    var y: Float,
    val width: Float = 34f,
    val height: Float = 34f,
    val patrolMinX: Float,
    val patrolMaxX: Float,
    val type: EnemyType,
    var vx: Float,
    var vy: Float = 0f,
    var baseY: Float = y,
    var animTimer: Float = 0f,
    var alive: Boolean = true
)

data class ActivePopcorn(
    val id: Int,
    var x: Float,
    var y: Float,
    val baseY: Float = y,
    var collected: Boolean = false,
    var bobOffset: Float = id * 0.7f
)

data class ActiveParticle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var size: Float,
    var color: Color,
    var life: Float,
    var maxLife: Float
)

data class FloatingText(
    var x: Float,
    var y: Float,
    var text: String,
    var color: Color,
    var life: Float = 0.85f
)

data class BossHazard(
    val id: Int,
    val type: HazardType,
    var x: Float,
    var y: Float,
    var width: Float,
    var height: Float,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var timer: Float = 0f,
    var active: Boolean = true
)

data class HeartPickup(
    var x: Float,
    var y: Float,
    var active: Boolean = true
)

data class BossState(
    var x: Float = 760f,
    var y: Float = 408f,
    val width: Float = 112f,
    val height: Float = 112f,
    var vx: Float = -110f,
    var vy: Float = 0f,
    var hp: Int = 24,
    val maxHp: Int = 24,
    var phase: Int = 1,
    var actionState: BossActionState = BossActionState.PATROL,
    var actionTimer: Float = 2.0f,
    var hitFlashTimer: Float = 0f,
    var facingRight: Boolean = false,
    var dashDir: Float = -1f,
    var alive: Boolean = true
)

data class HudSnapshot(
    val stageNumber: Int = 1,
    val stageTitle: String = "",
    val score: Int = 0,
    val highScore: Int = 0,
    val hearts: Int = 3,
    val maxHearts: Int = 3,
    val hasShield: Boolean = false,
    val stagePopcorn: Int = 0,
    val totalPopcorn: Int = 0,
    val isBossStage: Boolean = false,
    val bossHp: Int = 0,
    val bossMaxHp: Int = 24,
    val bossPhase: Int = 1,
    val isRestartingFromSpike: Boolean = false,
    val statusBanner: String? = null
)

class GameEngine(
    private val soundEngine: ArcadeSoundEngine,
    private val onStageCleared: (stageNumber: Int, score: Int, popcornEarned: Int) -> Unit,
    private val onGameOver: (score: Int, popcornEarned: Int) -> Unit,
    private val onHudUpdated: (HudSnapshot) -> Unit
) {
    companion object {
        const val GRAVITY = 1550f
        const val MAX_FALL_SPEED = 940f
        const val JUMP_VELOCITY = -775f
        const val BOUNCE_PAD_VELOCITY = -1020f
        const val BASE_MOVE_SPEED = 295f
        const val PLAYER_SIZE = 34f
        const val SPIN_DEG_PER_SEC = 900f
    }

    lateinit var level: LevelData
        private set

    var playerX = 76f
    var playerY = 480f
    var playerVx = 0f
    var playerVy = 0f
    var facingRight = true
    var onGround = false
    var isSpinningJump = false
    var spinAngle = 0f
    var squashX = 1f
    var squashY = 1f

    private var coyoteTimer = 0f
    private var jumpBufferTimer = 0f
    private var doubleJumpUsed = false
    private var invulnerableTimer = 0f
    private var spikeResetTimer = 0f
    private var bossVictoryTimer = 0f
    private var worldClock = 0f

    var cameraX = 0f
    var cameraY = 0f

    var score = 0
    var highScore = 0
    var baseTotalPopcorn = 0
    var stagePopcornCollected = 0
    var unsavedPopcorn = 0

    var hearts = 3
    var maxHearts = 3
    var hasShield = false

    // Power-up flags
    var doubleJumpEnabled = false
    var shieldEnabled = false
    var magnetEnabled = false
    var speedEnabled = false
    var superStompEnabled = false
    var extraHeartEnabled = false

    var graphicsQuality = GraphicsQuality.MEDIUM

    // Input flags
    @Volatile var leftPressed = false
    @Volatile var rightPressed = false
    private var jumpHeld = false

    val platforms = mutableListOf<ActivePlatform>()
    val enemies = mutableListOf<ActiveEnemy>()
    val popcornItems = mutableListOf<ActivePopcorn>()
    val particles = mutableListOf<ActiveParticle>()
    val floatingTexts = mutableListOf<FloatingText>()
    val bossHazards = mutableListOf<BossHazard>()
    val heartPickups = mutableListOf<HeartPickup>()
    var boss: BossState? = null

    private var nextDynamicId = 1000
    private var hudBroadcastAccumulator = 0f
    private var isPausedOrEnded = false
    private var statusBanner: String? = null
    private var bannerTimer = 0f

    fun loadStage(
        stageNumber: Int,
        currentScore: Int,
        savedHighScore: Int,
        savedPopcorn: Int,
        equippedPowerUps: Set<String>,
        quality: GraphicsQuality,
        preserveHearts: Boolean = false
    ) {
        level = LevelGenerator.getLevel(stageNumber)
        score = currentScore
        highScore = max(savedHighScore, currentScore)
        baseTotalPopcorn = savedPopcorn
        stagePopcornCollected = 0
        unsavedPopcorn = 0
        graphicsQuality = quality

        doubleJumpEnabled = "double_jump" in equippedPowerUps
        shieldEnabled = "butter_shield" in equippedPowerUps
        magnetEnabled = "popcorn_magnet" in equippedPowerUps
        speedEnabled = "speed_kernel" in equippedPowerUps
        superStompEnabled = "super_stomp" in equippedPowerUps
        extraHeartEnabled = "extra_heart" in equippedPowerUps

        maxHearts = if (extraHeartEnabled) 4 else 3
        if (!preserveHearts) {
            hearts = maxHearts
        } else {
            hearts = hearts.coerceIn(1, maxHearts)
        }
        hasShield = shieldEnabled
        isPausedOrEnded = false
        spikeResetTimer = 0f
        bossVictoryTimer = 0f
        statusBanner = if (level.isBossStage) "BOSS: BURNT KERNEL EMPEROR!" else null
        bannerTimer = if (level.isBossStage) 2.5f else 0f

        soundEngine.isBossMusic = level.isBossStage

        resetEntitiesForCurrentLevel()
        broadcastHud()
    }

    private fun resetEntitiesForCurrentLevel() {
        playerX = level.spawnX
        playerY = level.spawnY
        playerVx = 0f
        playerVy = 0f
        facingRight = true
        onGround = false
        isSpinningJump = false
        spinAngle = 0f
        squashX = 1f
        squashY = 1f
        coyoteTimer = 0f
        jumpBufferTimer = 0f
        doubleJumpUsed = false
        invulnerableTimer = 0.6f

        platforms.clear()
        level.platforms.forEachIndexed { idx, def ->
            platforms.add(
                ActivePlatform(
                    baseX = def.x,
                    baseY = def.y,
                    width = def.width,
                    height = def.height,
                    type = def.type,
                    moveRange = def.moveRange,
                    moveSpeed = def.moveSpeed,
                    phase = idx * 0.8f
                )
            )
        }

        enemies.clear()
        level.enemies.forEachIndexed { idx, def ->
            val speed = when (def.type) {
                EnemyType.KERNEL_WALKER -> 78f
                EnemyType.SALTY_HOPPER -> 88f
                EnemyType.CARAMEL_CHARGER -> 142f
                EnemyType.NEON_DRONE -> 115f
                EnemyType.CHILI_SPIRIT -> 132f
            }
            enemies.add(
                ActiveEnemy(
                    id = idx + 1,
                    x = def.x,
                    y = def.y,
                    patrolMinX = def.patrolMinX,
                    patrolMaxX = def.patrolMaxX,
                    type = def.type,
                    vx = if (idx % 2 == 0) speed else -speed,
                    baseY = def.y,
                    animTimer = idx * 0.45f
                )
            )
        }

        popcornItems.clear()
        level.popcorn.forEach { def ->
            popcornItems.add(ActivePopcorn(id = def.id, x = def.x, y = def.y))
        }

        particles.clear()
        floatingTexts.clear()
        bossHazards.clear()
        heartPickups.clear()

        boss = if (level.isBossStage) {
            BossState(
                x = 840f,
                y = 408f,
                hp = 24,
                maxHp = 24,
                phase = 1,
                actionState = BossActionState.PATROL,
                actionTimer = 1.8f,
                alive = true
            )
        } else {
            null
        }

        cameraX = (playerX - 200f).coerceAtLeast(0f)
        cameraY = 0f
    }

    fun onJumpPressed() {
        jumpHeld = true
        jumpBufferTimer = 0.14f
        if (!isPausedOrEnded && spikeResetTimer <= 0f) {
            attemptJump()
        }
    }

    fun onJumpReleased() {
        jumpHeld = false
        if (playerVy < -300f) {
            playerVy *= 0.68f
        }
    }

    private fun attemptJump() {
        if (onGround || coyoteTimer > 0f) {
            playerVy = JUMP_VELOCITY
            onGround = false
            coyoteTimer = 0f
            jumpBufferTimer = 0f
            isSpinningJump = true
            squashX = 0.82f
            squashY = 1.22f
            soundEngine.playSfx(SoundEffect.JUMP)
            spawnBurst(playerX + PLAYER_SIZE * 0.5f, playerY + PLAYER_SIZE, Color(0xFFFFF8E7), 5)
        } else if (doubleJumpEnabled && !doubleJumpUsed) {
            doubleJumpUsed = true
            playerVy = JUMP_VELOCITY * 0.94f
            jumpBufferTimer = 0f
            isSpinningJump = true
            squashX = 0.8f
            squashY = 1.24f
            soundEngine.playSfx(SoundEffect.DOUBLE_JUMP)
            spawnBurst(playerX + PLAYER_SIZE * 0.5f, playerY + PLAYER_SIZE, Color(0xFF22E4FF), 8)
        }
    }

    fun step(dtRaw: Float, viewportWorldWidth: Float, viewportWorldHeight: Float) {
        if (isPausedOrEnded) return
        val dt = dtRaw.coerceIn(0.001f, 0.035f)
        worldClock += dt

        if (bannerTimer > 0f) {
            bannerTimer -= dt
            if (bannerTimer <= 0f) statusBanner = null
        }

        updateParticlesAndTexts(dt)

        // Handle post-boss victory fireworks delay before Victory screen
        if (bossVictoryTimer > 0f) {
            bossVictoryTimer -= dt
            if (Random.nextFloat() < 0.35f) {
                spawnBurst(
                    x = (boss?.x ?: 660f) + Random.nextFloat() * 110f,
                    y = (boss?.y ?: 400f) + Random.nextFloat() * 110f,
                    color = Color(0xFFFFC83D),
                    count = 10
                )
            }
            if (bossVictoryTimer <= 0f) {
                isPausedOrEnded = true
                onStageCleared(level.stageNumber, score, unsavedPopcorn)
            }
            return
        }

        // Handle brief spike-death level restart delay
        if (spikeResetTimer > 0f) {
            spikeResetTimer -= dt
            if (spikeResetTimer <= 0f) {
                resetEntitiesForCurrentLevel()
                statusBanner = "Stage ${level.stageNumber} Restarted!"
                bannerTimer = 1.2f
                broadcastHud()
            }
            return
        }

        updatePlatforms(dt)
        updatePlayer(dt)
        updateEnemies(dt)
        updatePopcorn(dt)
        updateHeartPickups(dt)
        updateBoss(dt)
        checkSpikesAndBounds()
        checkGoal()

        // Smooth camera tracking
        val targetCamX = (playerX + PLAYER_SIZE * 0.5f - viewportWorldWidth * 0.38f)
            .coerceIn(0f, max(0f, level.width - viewportWorldWidth))
        val targetCamY = (playerY + PLAYER_SIZE * 0.5f - viewportWorldHeight * 0.58f)
            .coerceIn(-40f, max(-40f, level.height - viewportWorldHeight))
        cameraX += (targetCamX - cameraX) * min(1f, dt * 8.5f)
        cameraY += (targetCamY - cameraY) * min(1f, dt * 6.5f)

        hudBroadcastAccumulator += dt
        if (hudBroadcastAccumulator >= 0.08f) {
            hudBroadcastAccumulator = 0f
            broadcastHud()
        }
    }

    private fun updatePlatforms(dt: Float) {
        for (p in platforms) {
            p.prevX = p.x
            p.prevY = p.y
            if (p.type == PlatformType.MOVING_H && p.moveRange > 0f) {
                p.phase += dt * p.moveSpeed
                val norm = (sin(p.phase) + 1f) * 0.5f
                p.x = p.baseX + norm * p.moveRange
            } else if (p.type == PlatformType.MOVING_V && p.moveRange > 0f) {
                p.phase += dt * p.moveSpeed
                val norm = (sin(p.phase) + 1f) * 0.5f
                p.y = p.baseY + norm * p.moveRange
            }
        }
    }

    private fun updatePlayer(dt: Float) {
        if (invulnerableTimer > 0f) invulnerableTimer -= dt
        if (coyoteTimer > 0f) coyoteTimer -= dt
        if (jumpBufferTimer > 0f) jumpBufferTimer -= dt

        // Squash-and-stretch recovery
        squashX += (1f - squashX) * min(1f, dt * 12f)
        squashY += (1f - squashY) * min(1f, dt * 12f)

        val moveSpeed = if (speedEnabled) BASE_MOVE_SPEED * 1.2f else BASE_MOVE_SPEED
        val moveInput = (if (rightPressed) 1f else 0f) - (if (leftPressed) 1f else 0f)

        if (moveInput != 0f) {
            facingRight = moveInput > 0f
            val accel = if (onGround) 2400f else 1750f
            val targetVx = moveInput * moveSpeed
            if (playerVx < targetVx) {
                playerVx = min(targetVx, playerVx + accel * dt)
            } else if (playerVx > targetVx) {
                playerVx = max(targetVx, playerVx - accel * dt)
            }
        } else {
            val friction = if (onGround) 2200f else 850f
            if (abs(playerVx) <= friction * dt) {
                playerVx = 0f
            } else {
                playerVx -= kotlin.math.sign(playerVx) * friction * dt
            }
        }

        playerVy = min(MAX_FALL_SPEED, playerVy + GRAVITY * dt)

        val prevX = playerX
        val prevY = playerY

        // Horizontal movement + solid horizontal collision
        playerX += playerVx * dt
        playerX = playerX.coerceIn(0f, level.width - PLAYER_SIZE)

        for (p in platforms) {
            if (p.type == PlatformType.BOUNCY) continue
            if (aabbOverlap(playerX, playerY + 4f, PLAYER_SIZE, PLAYER_SIZE - 8f, p.x, p.y, p.width, p.height)) {
                if (prevX + PLAYER_SIZE <= p.x + 6f) {
                    playerX = p.x - PLAYER_SIZE
                    playerVx = 0f
                } else if (prevX >= p.x + p.width - 6f) {
                    playerX = p.x + p.width
                    playerVx = 0f
                }
            }
        }

        // Vertical movement + platform landing
        val wasOnGround = onGround
        onGround = false
        playerY += playerVy * dt

        for (p in platforms) {
            if (aabbOverlap(playerX + 2f, playerY, PLAYER_SIZE - 4f, PLAYER_SIZE, p.x, p.y, p.width, p.height)) {
                if (playerVy >= 0f && prevY + PLAYER_SIZE <= p.y + 16f) {
                    playerY = p.y - PLAYER_SIZE
                    if (p.type == PlatformType.BOUNCY) {
                        playerVy = BOUNCE_PAD_VELOCITY
                        onGround = false
                        doubleJumpUsed = false
                        isSpinningJump = true
                        squashX = 0.78f
                        squashY = 1.28f
                        soundEngine.playSfx(SoundEffect.DOUBLE_JUMP)
                        spawnBurst(playerX + PLAYER_SIZE * 0.5f, p.y, Color(0xFFFFC83D), 7)
                    } else {
                        playerVy = 0f
                        onGround = true
                        doubleJumpUsed = false
                        // Carry player with moving platform
                        playerX = (playerX + (p.x - p.prevX)).coerceIn(0f, level.width - PLAYER_SIZE)
                    }
                } else if (playerVy < 0f && p.type != PlatformType.BOUNCY && prevY >= p.y + p.height - 14f) {
                    playerY = p.y + p.height
                    playerVy = 0f
                }
            }
        }

        if (onGround) {
            coyoteTimer = 0.1f
            isSpinningJump = false
            spinAngle = 0f
            if (!wasOnGround) {
                squashX = 1.2f
                squashY = 0.82f
            }
            if (jumpBufferTimer > 0f) {
                attemptJump()
            }
        } else if (isSpinningJump) {
            val dir = if (facingRight) 1f else -1f
            spinAngle = (spinAngle + dir * SPIN_DEG_PER_SEC * dt) % 360f
        }
    }

    private fun updateEnemies(dt: Float) {
        val prevPlayerBottom = playerY - playerVy * dt + PLAYER_SIZE
        for (enemy in enemies) {
            if (!enemy.alive) continue
            enemy.animTimer += dt

            // Movement by archetype
            when (enemy.type) {
                EnemyType.KERNEL_WALKER, EnemyType.CARAMEL_CHARGER -> {
                    enemy.x += enemy.vx * dt
                    if (enemy.x <= enemy.patrolMinX) {
                        enemy.x = enemy.patrolMinX
                        enemy.vx = abs(enemy.vx)
                    } else if (enemy.x + enemy.width >= enemy.patrolMaxX) {
                        enemy.x = enemy.patrolMaxX - enemy.width
                        enemy.vx = -abs(enemy.vx)
                    }
                }

                EnemyType.SALTY_HOPPER -> {
                    enemy.x += enemy.vx * dt
                    if (enemy.x <= enemy.patrolMinX) {
                        enemy.x = enemy.patrolMinX
                        enemy.vx = abs(enemy.vx)
                    } else if (enemy.x + enemy.width >= enemy.patrolMaxX) {
                        enemy.x = enemy.patrolMaxX - enemy.width
                        enemy.vx = -abs(enemy.vx)
                    }
                    enemy.vy += 1200f * dt
                    enemy.y += enemy.vy * dt
                    if (enemy.y >= enemy.baseY) {
                        enemy.y = enemy.baseY
                        enemy.vy = -360f
                    }
                }

                EnemyType.NEON_DRONE, EnemyType.CHILI_SPIRIT -> {
                    enemy.x += enemy.vx * dt
                    if (enemy.x <= enemy.patrolMinX) {
                        enemy.x = enemy.patrolMinX
                        enemy.vx = abs(enemy.vx)
                    } else if (enemy.x + enemy.width >= enemy.patrolMaxX) {
                        enemy.x = enemy.patrolMaxX - enemy.width
                        enemy.vx = -abs(enemy.vx)
                    }
                    val amp = if (enemy.type == EnemyType.NEON_DRONE) 22f else 14f
                    enemy.y = enemy.baseY + sin(enemy.animTimer * 3.5f) * amp
                }
            }

            // Collision with Cubey
            if (aabbOverlap(playerX + 3f, playerY + 3f, PLAYER_SIZE - 6f, PLAYER_SIZE - 4f, enemy.x, enemy.y, enemy.width, enemy.height)) {
                val isStomp = playerVy > 0f && prevPlayerBottom <= enemy.y + enemy.height * 0.60f
                if (isStomp) {
                    enemy.alive = false
                    score += 1
                    if (score > highScore) highScore = score
                    playerVy = if (superStompEnabled) -680f else -580f
                    doubleJumpUsed = false
                    isSpinningJump = true
                    soundEngine.playSfx(SoundEffect.STOMP)
                    spawnBurst(enemy.x + enemy.width * 0.5f, enemy.y + enemy.height * 0.5f, Color(0xFFFF8C42), 10)
                    floatingTexts.add(FloatingText(enemy.x + 8f, enemy.y - 10f, "+1", Color(0xFF2ED573)))
                    broadcastHud()
                } else if (invulnerableTimer <= 0f) {
                    hurtPlayer(fromX = enemy.x + enemy.width * 0.5f)
                }
            }
        }
    }

    private fun updatePopcorn(dt: Float) {
        val px = playerX + PLAYER_SIZE * 0.5f
        val py = playerY + PLAYER_SIZE * 0.5f

        for (item in popcornItems) {
            if (item.collected) continue
            item.bobOffset += dt * 3.2f
            val visualY = item.baseY + sin(item.bobOffset) * 5f

            if (magnetEnabled) {
                val dist = hypot(px - item.x, py - item.y)
                if (dist < 175f && dist > 1f) {
                    val pull = 440f * dt
                    item.x += ((px - item.x) / dist) * pull
                    item.y += ((py - item.y) / dist) * pull
                }
            }

            val checkY = if (magnetEnabled) item.y else visualY
            if (hypot(px - item.x, py - checkY) < 30f) {
                item.collected = true
                stagePopcornCollected++
                unsavedPopcorn++
                soundEngine.playSfx(SoundEffect.POPCORN)
                spawnBurst(item.x, checkY, Color(0xFFFFC83D), 6)
                floatingTexts.add(FloatingText(item.x - 8f, checkY - 12f, "+1", Color(0xFFFFC83D)))
                broadcastHud()
            }
        }
    }

    private fun updateHeartPickups(dt: Float) {
        val px = playerX + PLAYER_SIZE * 0.5f
        val py = playerY + PLAYER_SIZE * 0.5f
        for (hp in heartPickups) {
            if (!hp.active) continue
            if (hypot(px - hp.x, py - hp.y) < 32f) {
                hp.active = false
                if (hearts < maxHearts) {
                    hearts++
                    floatingTexts.add(FloatingText(hp.x - 10f, hp.y - 14f, "+1 HP", Color(0xFFFF4757)))
                } else {
                    unsavedPopcorn += 3
                    floatingTexts.add(FloatingText(hp.x - 10f, hp.y - 14f, "+3", Color(0xFFFFC83D)))
                }
                soundEngine.playSfx(SoundEffect.POWERUP)
                spawnBurst(hp.x, hp.y, Color(0xFFFF4757), 8)
                broadcastHud()
            }
        }
    }

    private fun updateBoss(dt: Float) {
        val b = boss ?: return
        if (!b.alive) return

        if (b.hitFlashTimer > 0f) b.hitFlashTimer -= dt

        // Update Boss Hazards (Shockwaves, Butter Bombs, Temp Spikes)
        val prevPlayerBottom = playerY - playerVy * dt + PLAYER_SIZE
        for (h in bossHazards) {
            if (!h.active) continue
            h.timer -= dt
            when (h.type) {
                HazardType.SHOCKWAVE -> {
                    h.x += h.vx * dt
                    if (h.x < -60f || h.x > level.width + 60f || h.timer <= 0f) {
                        h.active = false
                    } else if (invulnerableTimer <= 0f && aabbOverlap(playerX + 4f, playerY + 4f, PLAYER_SIZE - 8f, PLAYER_SIZE - 4f, h.x, h.y, h.width, h.height)) {
                        hurtPlayer(h.x + h.width * 0.5f)
                    }
                }
                HazardType.BUTTER_BOMB -> {
                    h.vy += 900f * dt
                    h.x += h.vx * dt
                    h.y += h.vy * dt
                    if (h.y > 520f || h.timer <= 0f) {
                        h.active = false
                        spawnBurst(h.x, 515f, Color(0xFFFFC83D), 5)
                    } else if (invulnerableTimer <= 0f && aabbOverlap(playerX + 4f, playerY + 4f, PLAYER_SIZE - 8f, PLAYER_SIZE - 4f, h.x, h.y, h.width, h.height)) {
                        h.active = false
                        hurtPlayer(h.x + h.width * 0.5f)
                    }
                }
                HazardType.TEMP_SPIKE -> {
                    if (h.timer <= 0f) {
                        h.active = false
                    } else if (h.timer < 2.2f) {
                        // First 1.0s (3.2 -> 2.2) is warning telegraph; last 2.2s is active spike!
                        if (aabbOverlap(playerX + 6f, playerY + 4f, PLAYER_SIZE - 12f, PLAYER_SIZE - 6f, h.x, h.y, h.width, h.height)) {
                            killPlayerBySpike()
                            return
                        }
                    }
                }
            }
        }
        bossHazards.removeAll { !it.active }

        // Boss AI State Machine
        b.actionTimer -= dt
        val groundFloorY = 520f - b.height
        val speedMultiplier = 1f + (b.phase - 1) * 0.25f

        when (b.actionState) {
            BossActionState.PHASE_TRANSITION -> {
                b.vy += GRAVITY * dt
                b.y = min(groundFloorY, b.y + b.vy * dt)
                if (b.actionTimer <= 0f) {
                    b.actionState = BossActionState.PATROL
                    b.actionTimer = 1.6f
                }
            }

            BossActionState.PATROL -> {
                val baseSpeed = 125f * speedMultiplier
                b.vx = if (b.facingRight) baseSpeed else -baseSpeed
                b.x += b.vx * dt
                if (b.x <= 80f) {
                    b.x = 80f
                    b.facingRight = true
                } else if (b.x + b.width >= level.width - 80f) {
                    b.x = level.width - 80f - b.width
                    b.facingRight = false
                }

                if (b.actionTimer <= 0f) {
                    // Choose next attack based on phase
                    val roll = Random.nextFloat()
                    when {
                        b.phase >= 3 && roll < 0.38f -> {
                            b.actionState = BossActionState.DASH_TELEGRAPH
                            b.dashDir = if (playerX < b.x) -1f else 1f
                            b.facingRight = b.dashDir > 0f
                            b.actionTimer = 0.8f
                        }
                        else -> {
                            b.actionState = BossActionState.LEAP_UP
                            b.vy = -760f
                            b.vx = (playerX - b.x).coerceIn(-240f, 240f)
                            b.actionTimer = 3.0f
                            soundEngine.playSfx(SoundEffect.BOSS_ROAR)
                        }
                    }
                }
            }

            BossActionState.LEAP_UP -> {
                b.vy += GRAVITY * 0.9f * dt
                b.x = (b.x + b.vx * dt).coerceIn(70f, level.width - 70f - b.width)
                b.y += b.vy * dt
                if (b.y >= groundFloorY) {
                    b.y = groundFloorY
                    b.vy = 0f
                    b.vx = 0f
                    b.actionState = BossActionState.SLAM_RECOVERY
                    b.actionTimer = max(0.85f, 1.45f - b.phase * 0.14f)
                    soundEngine.playSfx(SoundEffect.BOSS_HIT)
                    spawnBossShockwaves(b)
                    if (b.phase >= 2) spawnBossPhaseExtras(b)
                }
            }

            BossActionState.SLAM_RECOVERY -> {
                if (b.actionTimer <= 0f) {
                    b.actionState = BossActionState.PATROL
                    b.actionTimer = max(1.1f, 2.2f - b.phase * 0.24f)
                }
            }

            BossActionState.DASH_TELEGRAPH -> {
                if (b.actionTimer <= 0f) {
                    b.actionState = BossActionState.DASH_CHARGE
                    b.actionTimer = 0.95f
                    soundEngine.playSfx(SoundEffect.BOSS_ROAR)
                }
            }

            BossActionState.DASH_CHARGE -> {
                val dashSpeed = 480f + b.phase * 45f
                b.x += b.dashDir * dashSpeed * dt
                if (b.x <= 60f || b.x + b.width >= level.width - 60f || b.actionTimer <= 0f) {
                    b.x = b.x.coerceIn(60f, level.width - 60f - b.width)
                    b.actionState = BossActionState.SLAM_RECOVERY
                    b.actionTimer = 1.15f
                }
            }
        }

        // Boss vs Cubey collision
        if (aabbOverlap(playerX + 4f, playerY + 4f, PLAYER_SIZE - 8f, PLAYER_SIZE - 4f, b.x + 6f, b.y, b.width - 12f, b.height - 2f)) {
            val isCrownStomp = playerVy > 0f && prevPlayerBottom <= b.y + b.height * 0.48f
            if (isCrownStomp && b.hitFlashTimer <= 0f && b.actionState != BossActionState.PHASE_TRANSITION) {
                val dmg = if (superStompEnabled) 2 else 1
                b.hp = max(0, b.hp - dmg)
                b.hitFlashTimer = 0.45f
                score += 1
                if (score > highScore) highScore = score
                playerVy = -700f
                playerVx = if (playerX + PLAYER_SIZE * 0.5f < b.x + b.width * 0.5f) -260f else 260f
                doubleJumpUsed = false
                isSpinningJump = true
                soundEngine.playSfx(SoundEffect.BOSS_HIT)
                spawnBurst(b.x + b.width * 0.5f, b.y + 16f, Color(0xFFFFC83D), 12)
                floatingTexts.add(FloatingText(b.x + 36f, b.y - 16f, "+1 (-$dmg HP)", Color(0xFF2ED573)))

                val newPhase = when {
                    b.hp > 18 -> 1
                    b.hp > 12 -> 2
                    b.hp > 6 -> 3
                    else -> 4
                }
                if (b.hp <= 0) {
                    b.alive = false
                    bossHazards.clear()
                    enemies.forEach { it.alive = false }
                    statusBanner = "EMPEROR DEFEATED!"
                    bannerTimer = 3.0f
                    bossVictoryTimer = 1.6f
                    soundEngine.playSfx(SoundEffect.STAGE_CLEAR)
                } else if (newPhase > b.phase) {
                    b.phase = newPhase
                    b.actionState = BossActionState.PHASE_TRANSITION
                    b.actionTimer = 1.4f
                    statusBanner = "PHASE ${b.phase}!"
                    bannerTimer = 1.8f
                    soundEngine.playSfx(SoundEffect.BOSS_ROAR)
                    // Spawn a helpful Heart pickup on the center vantage platform & bonus popcorn
                    heartPickups.add(HeartPickup(x = 660f, y = 285f))
                    for (i in 0..3) {
                        popcornItems.add(
                            ActivePopcorn(
                                id = nextDynamicId++,
                                x = 200f + i * 280f,
                                y = 465f
                            )
                        )
                    }
                }
                broadcastHud()
            } else if (invulnerableTimer <= 0f && b.actionState != BossActionState.PHASE_TRANSITION) {
                hurtPlayer(b.x + b.width * 0.5f)
            }
        }
    }

    private fun spawnBossShockwaves(b: BossState) {
        val waveSpeed = 240f + b.phase * 35f
        bossHazards.add(
            BossHazard(
                id = nextDynamicId++,
                type = HazardType.SHOCKWAVE,
                x = b.x - 16f,
                y = 492f,
                width = 28f,
                height = 28f,
                vx = -waveSpeed,
                timer = 4.0f
            )
        )
        bossHazards.add(
            BossHazard(
                id = nextDynamicId++,
                type = HazardType.SHOCKWAVE,
                x = b.x + b.width - 12f,
                y = 492f,
                width = 28f,
                height = 28f,
                vx = waveSpeed,
                timer = 4.0f
            )
        )
    }

    private fun spawnBossPhaseExtras(b: BossState) {
        // Summon up to 2 mini-kernel minions (player can stomp them for +1 score!)
        val activeMinions = enemies.count { it.alive }
        if (activeMinions < 2) {
            val spawnX = if (playerX < 660f) 960f else 300f
            enemies.add(
                ActiveEnemy(
                    id = nextDynamicId++,
                    x = spawnX,
                    y = 520f - 34f,
                    patrolMinX = 80f,
                    patrolMaxX = level.width - 80f,
                    type = if (b.phase >= 4) EnemyType.CARAMEL_CHARGER else EnemyType.KERNEL_WALKER,
                    vx = if (spawnX > 660f) -105f else 105f
                )
            )
        }

        // Erupt temporary telegraphed floor spikes near player's previous spot
        if (b.phase >= 2 && bossHazards.count { it.type == HazardType.TEMP_SPIKE } < 2) {
            val spikeX = (playerX - 24f).coerceIn(140f, level.width - 210f)
            bossHazards.add(
                BossHazard(
                    id = nextDynamicId++,
                    type = HazardType.TEMP_SPIKE,
                    x = spikeX,
                    y = 520f - 26f,
                    width = 56f,
                    height = 26f,
                    timer = 3.2f
                )
            )
        }

        // Lob arcing butter bombs in Phase 3 & 4
        if (b.phase >= 3) {
            val dir = if (playerX < b.x) -1f else 1f
            bossHazards.add(
                BossHazard(
                    id = nextDynamicId++,
                    type = HazardType.BUTTER_BOMB,
                    x = b.x + b.width * 0.5f,
                    y = b.y + 20f,
                    width = 22f,
                    height = 22f,
                    vx = dir * (190f + Random.nextFloat() * 140f),
                    vy = -480f,
                    timer = 3.0f
                )
            )
        }
    }

    private fun checkSpikesAndBounds() {
        // Out of bounds fall
        if (playerY > level.height + 50f) {
            killPlayerBySpike()
            return
        }

        for (s in level.spikes) {
            // Forgiving 5px horizontal inset so corner pixel grazing never feels unfair
            if (aabbOverlap(playerX + 5f, playerY + 4f, PLAYER_SIZE - 10f, PLAYER_SIZE - 4f, s.x + 4f, s.y + 4f, s.width - 8f, s.height - 4f)) {
                killPlayerBySpike()
                return
            }
        }
    }

    private fun killPlayerBySpike() {
        if (spikeResetTimer > 0f || isPausedOrEnded) return
        soundEngine.playSfx(SoundEffect.SPIKE_DEATH)
        spawnBurst(playerX + PLAYER_SIZE * 0.5f, playerY + PLAYER_SIZE * 0.5f, Color(0xFFFF4757), 16)
        hearts -= 1
        if (hearts <= 0) {
            hearts = 0
            triggerGameOver()
        } else {
            spikeResetTimer = 0.45f
            statusBanner = "Spiked! Restarting Stage ${level.stageNumber}..."
            bannerTimer = 1.4f
            broadcastHud()
        }
    }

    private fun hurtPlayer(fromX: Float) {
        if (invulnerableTimer > 0f || isPausedOrEnded) return
        soundEngine.playSfx(SoundEffect.HURT)

        val pushDir = if (playerX + PLAYER_SIZE * 0.5f < fromX) -1f else 1f
        playerVx = pushDir * 260f
        playerVy = -320f
        invulnerableTimer = 1.25f

        if (hasShield) {
            hasShield = false
            spawnBurst(playerX + PLAYER_SIZE * 0.5f, playerY + PLAYER_SIZE * 0.5f, Color(0xFFFFC83D), 12)
            floatingTexts.add(FloatingText(playerX, playerY - 12f, "SHIELD!", Color(0xFFFFC83D)))
            broadcastHud()
            return
        }

        hearts -= 1
        spawnBurst(playerX + PLAYER_SIZE * 0.5f, playerY + PLAYER_SIZE * 0.5f, Color(0xFFFF4757), 10)
        if (hearts <= 0) {
            hearts = 0
            triggerGameOver()
        } else {
            broadcastHud()
        }
    }

    private fun triggerGameOver() {
        isPausedOrEnded = true
        if (score > highScore) highScore = score
        soundEngine.playSfx(SoundEffect.GAME_OVER)
        broadcastHud()
        onGameOver(score, unsavedPopcorn)
    }

    private fun checkGoal() {
        if (level.isBossStage) return
        val px = playerX + PLAYER_SIZE * 0.5f
        val py = playerY + PLAYER_SIZE * 0.5f
        if (hypot(px - level.goalX, py - (level.goalY + 38f)) < 46f) {
            isPausedOrEnded = true
            soundEngine.playSfx(SoundEffect.STAGE_CLEAR)
            spawnBurst(level.goalX, level.goalY + 20f, Color(0xFFFFC83D), 18)
            broadcastHud()
            onStageCleared(level.stageNumber, score, unsavedPopcorn)
        }
    }

    private fun updateParticlesAndTexts(dt: Float) {
        var i = particles.size - 1
        while (i >= 0) {
            val p = particles[i]
            p.life -= dt
            if (p.life <= 0f) {
                particles.removeAt(i)
            } else {
                p.vy += 650f * dt
                p.x += p.vx * dt
                p.y += p.vy * dt
            }
            i--
        }

        var t = floatingTexts.size - 1
        while (t >= 0) {
            val ft = floatingTexts[t]
            ft.life -= dt
            if (ft.life <= 0f) {
                floatingTexts.removeAt(t)
            } else {
                ft.y -= 42f * dt
            }
            t--
        }
    }

    private fun spawnBurst(x: Float, y: Float, color: Color, count: Int) {
        val actualCount = when (graphicsQuality) {
            GraphicsQuality.LOW -> 0
            GraphicsQuality.MEDIUM -> (count / 2).coerceAtLeast(2)
            GraphicsQuality.HIGH -> count
        }
        if (actualCount <= 0 || particles.size > 90) return
        for (i in 0 until actualCount) {
            val angle = Random.nextFloat() * 2f * PI.toFloat()
            val speed = 80f + Random.nextFloat() * 190f
            val life = 0.35f + Random.nextFloat() * 0.35f
            particles.add(
                ActiveParticle(
                    x = x,
                    y = y,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed - 60f,
                    size = 4f + Random.nextFloat() * 4f,
                    color = color,
                    life = life,
                    maxLife = life
                )
            )
        }
    }

    fun isPlayerInvulnerable(): Boolean = invulnerableTimer > 0f
    fun isPlayerDyingFromSpike(): Boolean = spikeResetTimer > 0f
    fun getWorldClock(): Float = worldClock

    fun broadcastHud() {
        val b = boss
        onHudUpdated(
            HudSnapshot(
                stageNumber = level.stageNumber,
                stageTitle = level.title,
                score = score,
                highScore = max(highScore, score),
                hearts = hearts,
                maxHearts = maxHearts,
                hasShield = hasShield,
                stagePopcorn = stagePopcornCollected,
                totalPopcorn = baseTotalPopcorn + unsavedPopcorn,
                isBossStage = level.isBossStage,
                bossHp = b?.hp ?: 0,
                bossMaxHp = b?.maxHp ?: 24,
                bossPhase = b?.phase ?: 1,
                isRestartingFromSpike = spikeResetTimer > 0f,
                statusBanner = statusBanner
            )
        )
    }

    private fun aabbOverlap(
        ax: Float, ay: Float, aw: Float, ah: Float,
        bx: Float, by: Float, bw: Float, bh: Float
    ): Boolean {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by
    }
}
