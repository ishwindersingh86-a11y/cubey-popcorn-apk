package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.withTransform
import com.example.data.GraphicsQuality
import com.example.game.BossActionState
import com.example.game.EnemyType
import com.example.game.GameEngine
import com.example.game.HazardType
import com.example.game.PlatformType
import com.example.game.SpikeDirection
import com.example.game.WorldTheme
import com.example.game.WorldThemes
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GameCanvas(
    engine: GameEngine,
    frameTick: Long,
    viewportWorldWidth: Float,
    viewportWorldHeight: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        // Read frameTick so Compose invalidates draw phase every frame cleanly
        @Suppress("UNUSED_VARIABLE")
        val tick = frameTick

        val theme = WorldThemes.forStage(engine.level.stageNumber)
        val quality = engine.graphicsQuality

        val scaleX = size.width / viewportWorldWidth
        val scaleY = size.height / viewportWorldHeight
        val worldScale = minOf(scaleX, scaleY)
        val offsetX = (size.width - viewportWorldWidth * worldScale) * 0.5f
        val offsetY = (size.height - viewportWorldHeight * worldScale) * 0.5f

        // 1. Background sky + optional parallax (respecting GraphicsQuality)
        drawWorldBackdrop(theme, quality, engine.cameraX, engine.getWorldClock())

        // 2. World-space rendering
        withTransform({
            translate(left = offsetX, top = offsetY)
            scale(scaleX = worldScale, scaleY = worldScale, pivot = Offset.Zero)
            translate(left = -engine.cameraX, top = -engine.cameraY)
        }) {
            val viewLeft = engine.cameraX - 80f
            val viewRight = engine.cameraX + viewportWorldWidth + 80f

            // Platforms
            for (p in engine.platforms) {
                if (p.x + p.width < viewLeft || p.x > viewRight) continue
                drawPlatform(p.x, p.y, p.width, p.height, p.type, theme, quality)
            }

            // Static Spikes
            for (s in engine.level.spikes) {
                if (s.x + s.width < viewLeft || s.x > viewRight) continue
                drawSpikeCluster(s.x, s.y, s.width, s.height, s.direction, theme.spikeColor, quality)
            }

            // Boss Arena Goal / Standard Popcorn Bucket Goal
            if (!engine.level.isBossStage || (engine.boss?.alive == false)) {
                drawPopcornBucketGoal(engine.level.goalX, engine.level.goalY, engine.getWorldClock(), quality)
            }

            // Popcorn Collectibles
            for (item in engine.popcornItems) {
                if (item.collected) continue
                if (item.x < viewLeft - 40f || item.x > viewRight + 40f) continue
                val drawY = if (engine.magnetEnabled) item.y else item.baseY + sin(item.bobOffset) * 5f
                drawPopcornKernel(item.x, drawY, quality)
            }

            // Boss Heart Pickups
            for (hp in engine.heartPickups) {
                if (!hp.active) continue
                drawHeartPickup(hp.x, hp.y + sin(engine.getWorldClock() * 4f) * 4f)
            }

            // Enemies
            for (e in engine.enemies) {
                if (!e.alive) continue
                if (e.x + e.width < viewLeft || e.x > viewRight) continue
                drawEnemy(e.x, e.y, e.width, e.height, e.type, e.vx >= 0f, engine.getWorldClock(), quality)
            }

            // Stage 90 Boss & Boss Hazards
            engine.boss?.let { b ->
                if (b.alive) {
                    drawBoss(b, engine.getWorldClock(), quality)
                }
            }
            for (h in engine.bossHazards) {
                if (!h.active) continue
                when (h.type) {
                    HazardType.SHOCKWAVE -> {
                        drawRect(
                            color = Color(0xFFFF6B35),
                            topLeft = Offset(h.x, h.y),
                            size = Size(h.width, h.height)
                        )
                        drawCircle(
                            color = Color(0xFFFFE066),
                            radius = h.width * 0.4f,
                            center = Offset(h.x + h.width * 0.5f, h.y + h.height * 0.5f)
                        )
                    }
                    HazardType.BUTTER_BOMB -> {
                        drawCircle(
                            color = Color(0xFFFFC83D),
                            radius = h.width * 0.5f,
                            center = Offset(h.x + h.width * 0.5f, h.y + h.height * 0.5f)
                        )
                        drawCircle(
                            color = Color(0xFFFF4757),
                            radius = h.width * 0.25f,
                            center = Offset(h.x + h.width * 0.5f, h.y + h.height * 0.5f)
                        )
                    }
                    HazardType.TEMP_SPIKE -> {
                        if (h.timer >= 2.2f) {
                            // Telegraph warning zone
                            val alpha = 0.35f + 0.35f * abs(sin(engine.getWorldClock() * 14f))
                            drawRect(
                                color = Color(0xFFFF4757).copy(alpha = alpha),
                                topLeft = Offset(h.x, h.y + h.height - 8f),
                                size = Size(h.width, 8f)
                            )
                        } else {
                            drawSpikeCluster(h.x, h.y, h.width, h.height, SpikeDirection.UP, Color(0xFFFF2E63), quality)
                        }
                    }
                }
            }

            // Cubey Hero (with spin while jumping!)
            if (!engine.isPlayerDyingFromSpike()) {
                val blinkHide = engine.isPlayerInvulnerable() && ((engine.getWorldClock() * 18f).toInt() % 2 == 0)
                if (!blinkHide) {
                    drawCubey(
                        x = engine.playerX,
                        y = engine.playerY,
                        sizePx = GameEngine.PLAYER_SIZE,
                        facingRight = engine.facingRight,
                        spinAngle = engine.spinAngle,
                        isSpinning = engine.isSpinningJump,
                        squashX = engine.squashX,
                        squashY = engine.squashY,
                        hasShield = engine.hasShield,
                        quality = quality
                    )
                }
            }

            // Particles (Medium & High only)
            if (quality != GraphicsQuality.LOW) {
                for (pt in engine.particles) {
                    val alpha = (pt.life / pt.maxLife).coerceIn(0f, 1f)
                    drawCircle(
                        color = pt.color.copy(alpha = alpha),
                        radius = pt.size,
                        center = Offset(pt.x, pt.y)
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawWorldBackdrop(
    theme: WorldTheme,
    quality: GraphicsQuality,
    cameraX: Float,
    clock: Float
) {
    if (quality == GraphicsQuality.LOW) {
        drawRect(color = theme.skyBottom)
        return
    }

    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(theme.skyTop, theme.skyBottom)
        )
    )

    // Stars / cinema sparkles in HIGH
    if (quality == GraphicsQuality.HIGH) {
        for (i in 0 until 22) {
            val sx = ((i * 173f - cameraX * 0.12f) % size.width + size.width) % size.width
            val sy = ((i * 89f) % (size.height * 0.55f))
            val twinkle = 0.35f + 0.45f * abs(sin(clock * 1.8f + i))
            drawCircle(
                color = Color.White.copy(alpha = twinkle),
                radius = if (i % 3 == 0) 2.8f else 1.8f,
                center = Offset(sx, sy)
            )
        }
    }

    // Far parallax hills
    val farShift = -(cameraX * 0.18f) % 420f
    var hx = farShift - 420f
    while (hx < size.width + 420f) {
        drawOval(
            color = theme.hillFar,
            topLeft = Offset(hx, size.height * 0.58f),
            size = Size(500f, size.height * 0.65f)
        )
        hx += 380f
    }

    if (quality == GraphicsQuality.HIGH) {
        val nearShift = -(cameraX * 0.35f) % 340f
        var nx = nearShift - 340f
        while (nx < size.width + 340f) {
            drawOval(
                color = theme.hillNear,
                topLeft = Offset(nx, size.height * 0.72f),
                size = Size(390f, size.height * 0.52f)
            )
            nx += 310f
        }
    }
}

private fun DrawScope.drawPlatform(
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    type: PlatformType,
    theme: WorldTheme,
    quality: GraphicsQuality
) {
    if (type == PlatformType.BOUNCY) {
        drawRoundRect(
            color = Color(0xFFFF8C42),
            topLeft = Offset(x, y + 3f),
            size = Size(w, h - 3f),
            cornerRadius = CornerRadius(6f, 6f)
        )
        drawRoundRect(
            color = Color(0xFFFFD166),
            topLeft = Offset(x, y),
            size = Size(w, 6f),
            cornerRadius = CornerRadius(4f, 4f)
        )
        return
    }

    val bodyColor = if (type == PlatformType.MOVING_H || type == PlatformType.MOVING_V) {
        theme.accentColor.copy(alpha = 0.35f)
    } else {
        theme.platformBody
    }

    drawRoundRect(
        color = bodyColor,
        topLeft = Offset(x, y),
        size = Size(w, h),
        cornerRadius = CornerRadius(6f, 6f)
    )

    // Top turf / trim
    drawRoundRect(
        color = theme.platformTop,
        topLeft = Offset(x, y),
        size = Size(w, 8f),
        cornerRadius = CornerRadius(6f, 6f)
    )

    if (quality != GraphicsQuality.LOW) {
        drawRoundRect(
            color = theme.platformBorder,
            topLeft = Offset(x, y),
            size = Size(w, h),
            cornerRadius = CornerRadius(6f, 6f),
            style = Stroke(width = 2f)
        )
    }
}

private fun DrawScope.drawSpikeCluster(
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    direction: SpikeDirection,
    color: Color,
    quality: GraphicsQuality
) {
    val toothWidth = 14f
    val count = (w / toothWidth).toInt().coerceAtLeast(1)
    val actualToothW = w / count
    val path = Path()

    for (i in 0 until count) {
        val sx = x + i * actualToothW
        if (direction == SpikeDirection.UP) {
            path.moveTo(sx, y + h)
            path.lineTo(sx + actualToothW * 0.5f, y)
            path.lineTo(sx + actualToothW, y + h)
            path.close()
        } else {
            path.moveTo(sx, y)
            path.lineTo(sx + actualToothW * 0.5f, y + h)
            path.lineTo(sx + actualToothW, y)
            path.close()
        }
    }
    drawPath(path = path, color = color)
    if (quality != GraphicsQuality.LOW) {
        drawPath(path = path, color = Color.White.copy(alpha = 0.3f), style = Stroke(width = 1.4f))
    }
}

private fun DrawScope.drawCubey(
    x: Float,
    y: Float,
    sizePx: Float,
    facingRight: Boolean,
    spinAngle: Float,
    isSpinning: Boolean,
    squashX: Float,
    squashY: Float,
    hasShield: Boolean,
    quality: GraphicsQuality
) {
    val cx = x + sizePx * 0.5f
    val cy = y + sizePx * 0.5f

    // Spin trail ring in HIGH quality while airborne spinning
    if (isSpinning && quality == GraphicsQuality.HIGH) {
        drawCircle(
            color = Color(0xFF22E4FF).copy(alpha = 0.25f),
            radius = sizePx * 0.68f,
            center = Offset(cx, cy),
            style = Stroke(width = 4f)
        )
    }

    // Butter shield aura
    if (hasShield) {
        drawCircle(
            color = Color(0xFFFFC83D).copy(alpha = 0.35f),
            radius = sizePx * 0.78f,
            center = Offset(cx, cy),
            style = Stroke(width = 3.5f)
        )
    }

    withTransform({
        rotate(degrees = spinAngle, pivot = Offset(cx, cy))
        scale(scaleX = squashX, scaleY = squashY, pivot = Offset(cx, y + sizePx))
    }) {
        // Cubey outer cyan cube
        drawRoundRect(
            color = Color(0xFF00B4D8),
            topLeft = Offset(x, y),
            size = Size(sizePx, sizePx),
            cornerRadius = CornerRadius(7f, 7f)
        )
        // Bright front face
        drawRoundRect(
            color = Color(0xFF22E4FF),
            topLeft = Offset(x + 3f, y + 3f),
            size = Size(sizePx - 6f, sizePx - 6f),
            cornerRadius = CornerRadius(5f, 5f)
        )
        // Cute border
        drawRoundRect(
            color = Color(0xFF073B4C),
            topLeft = Offset(x, y),
            size = Size(sizePx, sizePx),
            cornerRadius = CornerRadius(7f, 7f),
            style = Stroke(width = 2.2f)
        )

        // Expressive eyes looking in movement direction
        val eyeShift = if (facingRight) 3f else -3f
        val leftEyeX = cx - 6f + eyeShift
        val rightEyeX = cx + 6f + eyeShift
        val eyeY = cy - 3f

        drawCircle(color = Color.White, radius = 4.6f, center = Offset(leftEyeX, eyeY))
        drawCircle(color = Color.White, radius = 4.6f, center = Offset(rightEyeX, eyeY))
        drawCircle(color = Color(0xFF0B132B), radius = 2.4f, center = Offset(leftEyeX + eyeShift * 0.35f, eyeY))
        drawCircle(color = Color(0xFF0B132B), radius = 2.4f, center = Offset(rightEyeX + eyeShift * 0.35f, eyeY))

        // Happy mouth
        drawArc(
            color = Color(0xFF0B132B),
            startAngle = 15f,
            sweepAngle = 150f,
            useCenter = false,
            topLeft = Offset(cx - 5f + eyeShift * 0.5f, cy + 2f),
            size = Size(10f, 7f),
            style = Stroke(width = 2f)
        )
    }
}

private fun DrawScope.drawPopcornKernel(x: Float, y: Float, quality: GraphicsQuality) {
    if (quality == GraphicsQuality.HIGH) {
        drawCircle(
            color = Color(0xFFFFC83D).copy(alpha = 0.22f),
            radius = 16f,
            center = Offset(x, y)
        )
    }
    // Fluffy popcorn silhouette made of 4 overlapping golden-cream puffs
    drawCircle(color = Color(0xFFFFC83D), radius = 8.5f, center = Offset(x, y + 2f))
    drawCircle(color = Color(0xFFFFE58F), radius = 6.5f, center = Offset(x - 5f, y - 3f))
    drawCircle(color = Color(0xFFFFF8E7), radius = 6.5f, center = Offset(x + 5f, y - 2f))
    drawCircle(color = Color(0xFFFFF8E7), radius = 5.5f, center = Offset(x, y - 6f))
}

private fun DrawScope.drawPopcornBucketGoal(x: Float, y: Float, clock: Float, quality: GraphicsQuality) {
    val bob = sin(clock * 2.5f) * 3f
    val topY = y + bob

    if (quality == GraphicsQuality.HIGH) {
        drawCircle(
            color = Color(0xFFFFC83D).copy(alpha = 0.18f),
            radius = 52f,
            center = Offset(x, topY + 26f)
        )
    }

    // Overflowing popcorn pile on top
    val puffs = listOf(-16f to -4f, -6f to -12f, 8f to -11f, 18f to -3f, 0f to -2f)
    for ((dx, dy) in puffs) {
        drawCircle(color = Color(0xFFFFC83D), radius = 10f, center = Offset(x + dx, topY + 8f + dy))
        drawCircle(color = Color(0xFFFFF8E7), radius = 7f, center = Offset(x + dx - 1f, topY + 6f + dy))
    }

    // Red-and-white striped cinema popcorn bucket
    val bucketPath = Path().apply {
        moveTo(x - 26f, topY + 12f)
        lineTo(x + 26f, topY + 12f)
        lineTo(x + 20f, topY + 74f)
        lineTo(x - 20f, topY + 74f)
        close()
    }
    drawPath(bucketPath, color = Color(0xFFFF4757))
    // White vertical center stripe
    val stripe = Path().apply {
        moveTo(x - 8f, topY + 12f)
        lineTo(x + 8f, topY + 12f)
        lineTo(x + 6f, topY + 74f)
        lineTo(x - 6f, topY + 74f)
        close()
    }
    drawPath(stripe, color = Color(0xFFFFF8E7))
    drawPath(bucketPath, color = Color(0xFF4A0E17), style = Stroke(width = 2.5f))
}

private fun DrawScope.drawHeartPickup(x: Float, y: Float) {
    drawCircle(color = Color(0xFFFF4757).copy(alpha = 0.25f), radius = 18f, center = Offset(x, y))
    drawCircle(color = Color(0xFFFF4757), radius = 7f, center = Offset(x - 5f, y - 3f))
    drawCircle(color = Color(0xFFFF4757), radius = 7f, center = Offset(x + 5f, y - 3f))
    val p = Path().apply {
        moveTo(x - 11.5f, y)
        lineTo(x + 11.5f, y)
        lineTo(x, y + 12f)
        close()
    }
    drawPath(p, color = Color(0xFFFF4757))
}

private fun DrawScope.drawEnemy(
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    type: EnemyType,
    facingRight: Boolean,
    clock: Float,
    quality: GraphicsQuality
) {
    val bodyColor = when (type) {
        EnemyType.KERNEL_WALKER -> Color(0xFFFF7F50)
        EnemyType.SALTY_HOPPER -> Color(0xFFA855F7)
        EnemyType.CARAMEL_CHARGER -> Color(0xFFD97706)
        EnemyType.NEON_DRONE -> Color(0xFFEC4899)
        EnemyType.CHILI_SPIRIT -> Color(0xFFEF4444)
    }

    drawRoundRect(
        color = bodyColor,
        topLeft = Offset(x, y),
        size = Size(w, h),
        cornerRadius = CornerRadius(10f, 10f)
    )
    if (quality != GraphicsQuality.LOW) {
        drawRoundRect(
            color = Color(0xFF1F102E),
            topLeft = Offset(x, y),
            size = Size(w, h),
            cornerRadius = CornerRadius(10f, 10f),
            style = Stroke(width = 2f)
        )
    }

    // Angry brows + eyes
    val dir = if (facingRight) 2.5f else -2.5f
    val cx = x + w * 0.5f
    val cy = y + h * 0.45f
    drawCircle(color = Color.White, radius = 4.2f, center = Offset(cx - 6f + dir, cy))
    drawCircle(color = Color.White, radius = 4.2f, center = Offset(cx + 6f + dir, cy))
    drawCircle(color = Color.Black, radius = 2.1f, center = Offset(cx - 6f + dir * 1.4f, cy))
    drawCircle(color = Color.Black, radius = 2.1f, center = Offset(cx + 6f + dir * 1.4f, cy))

    // Drone wings if flyer
    if (type == EnemyType.NEON_DRONE) {
        val wingY = y + 8f + sin(clock * 16f) * 4f
        drawRect(color = Color(0xFF00F5D4), topLeft = Offset(x - 8f, wingY), size = Size(8f, 6f))
        drawRect(color = Color(0xFF00F5D4), topLeft = Offset(x + w, wingY), size = Size(8f, 6f))
    }
}

private fun DrawScope.drawBoss(
    b: com.example.game.BossState,
    clock: Float,
    quality: GraphicsQuality
) {
    val isFlashing = b.hitFlashTimer > 0f && ((clock * 24f).toInt() % 2 == 0)
    val mainColor = when {
        isFlashing -> Color.White
        b.phase >= 4 -> Color(0xFFDC2626)
        b.phase == 3 -> Color(0xFF9333EA)
        b.phase == 2 -> Color(0xFFB45309)
        else -> Color(0xFF581C87)
    }

    // Dash telegraph warning banner above boss
    if (b.actionState == BossActionState.DASH_TELEGRAPH) {
        drawCircle(
            color = Color(0xFFFF4757).copy(alpha = 0.5f),
            radius = 24f,
            center = Offset(b.x + b.width * 0.5f, b.y - 26f)
        )
    }

    if (quality == GraphicsQuality.HIGH) {
        drawCircle(
            color = mainColor.copy(alpha = 0.25f),
            radius = b.width * 0.72f,
            center = Offset(b.x + b.width * 0.5f, b.y + b.height * 0.5f)
        )
    }

    // Boss armored cube body
    drawRoundRect(
        color = mainColor,
        topLeft = Offset(b.x, b.y),
        size = Size(b.width, b.height),
        cornerRadius = CornerRadius(18f, 18f)
    )
    drawRoundRect(
        color = Color(0xFFFFC83D),
        topLeft = Offset(b.x, b.y),
        size = Size(b.width, b.height),
        cornerRadius = CornerRadius(18f, 18f),
        style = Stroke(width = 4f)
    )

    // Golden Crown on top (stomp target!)
    val crownPath = Path().apply {
        moveTo(b.x + 22f, b.y)
        lineTo(b.x + 30f, b.y - 22f)
        lineTo(b.x + 48f, b.y - 6f)
        lineTo(b.x + 56f, b.y - 26f)
        lineTo(b.x + 64f, b.y - 6f)
        lineTo(b.x + 82f, b.y - 22f)
        lineTo(b.x + 90f, b.y)
        close()
    }
    drawPath(crownPath, color = Color(0xFFFFC83D))

    // Fierce glowing eyes
    val eyeShift = if (b.facingRight) 8f else -8f
    val cx = b.x + b.width * 0.5f + eyeShift
    val ey = b.y + 44f
    drawCircle(color = Color(0xFFFFE066), radius = 12f, center = Offset(cx - 22f, ey))
    drawCircle(color = Color(0xFFFFE066), radius = 12f, center = Offset(cx + 22f, ey))
    drawCircle(color = Color(0xFF1A0B2E), radius = 5.5f, center = Offset(cx - 22f + eyeShift * 0.3f, ey))
    drawCircle(color = Color(0xFF1A0B2E), radius = 5.5f, center = Offset(cx + 22f + eyeShift * 0.3f, ey))
}
